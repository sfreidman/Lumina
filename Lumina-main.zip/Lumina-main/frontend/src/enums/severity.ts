export enum Severity {
  DANGER = 'DANGER',
  WARNING = 'WARNING',
  INFO = 'INFO',
}
