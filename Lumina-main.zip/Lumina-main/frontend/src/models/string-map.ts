export interface StringMap {
  [key: string]: string
}
