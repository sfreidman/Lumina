export interface KeyValue<T, Y> {
  key: T
  value: Y
}
