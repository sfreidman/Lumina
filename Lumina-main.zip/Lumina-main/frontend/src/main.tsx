import { ThemeProvider } from '@emotion/react'
import { CssBaseline } from '@mui/material'
import { QueryCache, QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { RouterProvider, createRouter } from '@tanstack/react-router'
import { WebStorageStateStore } from 'oidc-client-ts'
import React from 'react'
import ReactDOM from 'react-dom/client'
import { AuthProvider, AuthProviderProps } from 'react-oidc-context'
import { toast } from 'react-toastify'
import { routeTree } from './routeTree.gen'
import theme from './theme/theme.ts'

// Fonts used by MUI
import '@fontsource/poppins/300.css'
import '@fontsource/poppins/400.css'
import '@fontsource/poppins/500.css'
import '@fontsource/poppins/700.css'
import 'react-toastify/dist/ReactToastify.min.css'
import { redirectToPreviousLocationAfterLogin } from './utils/auth-utils.ts'

// Initialize react-query
const queryClient = new QueryClient({
  queryCache: new QueryCache({
    onError: (error, query) => {
      // only show error toasts if we already have data in the cache
      // which indicates a failed background update
      if (query.state.data !== undefined) {
        toast.error(`Something went wrong: ${error.message}`)
      }
    },
  }),
})

// Set up a Router instance
const router = createRouter({
  routeTree,
  context: {
    queryClient,
  },
  defaultPreload: 'intent',
  defaultPreloadStaleTime: 0,
})

// Register things for typesafety
declare module '@tanstack/react-router' {
  interface Register {
    router: typeof router
  }
}

// Configure single sign-on
const oidcConfig: AuthProviderProps = {
  authority: import.meta.env.VITE_SSO_AUTHORITY,
  client_id: import.meta.env.VITE_SSO_CLIENT_ID,
  redirect_uri: window.location.origin,
  scope: 'openid profile email offline_access',
  response_type: 'code',
  automaticSilentRenew: true,
  onSigninCallback: redirectToPreviousLocationAfterLogin,
  onRemoveUser: () => {
    window.location.href = '/'
  },
  userStore: new WebStorageStateStore({ store: window.localStorage }),
  stateStore: new WebStorageStateStore({ store: window.localStorage }),
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <QueryClientProvider client={queryClient}>
        <AuthProvider {...oidcConfig}>
          <RouterProvider router={router} />
        </AuthProvider>
      </QueryClientProvider>
    </ThemeProvider>
  </React.StrictMode>,
)
