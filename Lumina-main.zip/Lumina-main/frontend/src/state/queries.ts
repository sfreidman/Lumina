import { useQuery } from '@tanstack/react-query'
import { atomWithQuery } from 'jotai-tanstack-query'
import { MRT_PaginationState, MRT_SortingState } from 'material-react-table'
import { getFromApi, type User } from '../api'
import { BuildRunAPI } from '../api/models/build-runs'
import { OutageAPI, OutageState } from '../api/models/outage'
import { PrFilters, PullRequestAPI, PullRequestPaginationAPI, PullRequestUI } from '../api/models/pull-request'
import { StageAPI } from '../api/models/stage'
import { buildRunSerializer } from '../api/serializers/build-run-serizlizer'
import { outageSerializer } from '../api/serializers/outage-serializer'
import { pullRequestSerializer } from '../api/serializers/pull-request-serializer'
import { stageSerializer } from '../api/serializers/stage-serializer'
import { StringMap } from '../models/string-map'
import { listSanitizer } from '../utils'
import { accessTokenAtom } from './atoms'

export const userMeQueryAtom = atomWithQuery<User | null>((get) => ({
  queryKey: ['users', get(accessTokenAtom)],
  queryFn: async ({ queryKey: [, accessToken] }) => {
    if (!accessToken) {
      return null
    }

    return await getFromApi<User>({
      url: 'users/me',
      accessToken: accessToken as string,
    })
  },
  staleTime: 1000 * 60 * 5, // 5 minutes
}))

export const prFiltersQueryAtom = atomWithQuery<PrFilters | null>(() => ({
  queryKey: ['prFilters'],
  queryFn: async () => {
    return await getFromApi<PrFilters>({
      url: 'pull-requests/pr-list/filters',
    })
  },
}))

export const useOutagesQuery = (state: OutageState, prId?: string, buildId?: string) => {
  const searchParams = new URLSearchParams({ state })
  if (buildId && prId) {
    searchParams.append('build_run_id', buildId)
    searchParams.append('pr_id', prId)
  }
  return useQuery({
    queryKey: ['outages', state, searchParams],
    queryFn: async () => {
      const res = await getFromApi<OutageAPI[]>({
        url: 'outages',
        queryParams: searchParams,
      })

      if (res) {
        const preSanitizedOutages = res.map(outageSerializer)
        return listSanitizer(preSanitizedOutages)
      }
    },
  })
}

export const usePRDetailsQuery = (prId: string) => {
  return useQuery({
    queryKey: ['pr-details', prId],
    queryFn: async () => {
      const res = await getFromApi<PullRequestAPI>({
        url: `pull-requests/${prId}`,
      })
      return pullRequestSerializer(res) as PullRequestUI
    },
  })
}

export const usePRRunsQuery = (prId: string) => {
  return useQuery({
    queryKey: ['pr-runs', prId],
    queryFn: async () => {
      const res = await getFromApi<BuildRunAPI[]>({
        url: `pull-requests/${prId}/pr-runs`,
      })
      if (res) {
        const preSanitizedBuildRuns = res.map(buildRunSerializer)
        return listSanitizer(preSanitizedBuildRuns)
      }
    },
  })
}

export const usePRListQuery = (pagination: MRT_PaginationState, sorting: MRT_SortingState, filters: StringMap) => {
  return useQuery({
    queryKey: [
      'pr-list',
      JSON.stringify(filters), //refetch when columnFilters changes
      pagination.pageIndex, //refetch when pagination.pageIndex changes
      pagination.pageSize, //refetch when pagination.pageSize changes
      JSON.stringify(sorting), //refetch when sorting changes
    ],
    queryFn: async () => {
      const queryParams = new URLSearchParams({
        offset: `${pagination.pageIndex * pagination.pageSize}`,
        limit: `${pagination.pageSize}`,
      })
      if (sorting.length > 0) {
        sorting.forEach((sort) => {
          let key = sort.id
          switch (sort.id) {
            case 'github_status':
              key = 'state'
              break
          }
          queryParams.append('order_by', `${sort.desc ? '-' : ''}${key}`)
        })
      }
      if (Object.keys(filters).length > 0) {
        for (const key in filters) {
          if (Object.prototype.hasOwnProperty.call(filters, key)) {
            queryParams.append(key, filters[key])
          }
        }
      }
      const res = await getFromApi<PullRequestPaginationAPI>({
        url: 'pull-requests/pr-list',
        queryParams,
      })
      return {
        ...res,
        results: res.results.map((pr: PullRequestAPI) => pullRequestSerializer(pr)),
      }
    },
  })
}

export const usePRRunsStagesQuery = (
  prId: string,
  aggregation: 'pr-runs' | 'pr-commits',
  commitSha?: string,
  buildId?: number,
) => {
  const id = commitSha ? commitSha : buildId
  return useQuery({
    queryKey: [prId, id, aggregation],
    queryFn: async () => {
      const res = await getFromApi<StageAPI[]>({
        url: `pull-requests/${prId}/${aggregation}/${id}/stages-status/`,
      })
      if (res) {
        const preSanitizedBuildRuns = res.map((stage) => stageSerializer(stage))
        return listSanitizer(preSanitizedBuildRuns)
      }
    },
  })
}
