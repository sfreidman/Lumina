import { atom } from 'jotai'

export const accessTokenAtom = atom<string | null | undefined>(null)
export const tabsContentHeightAtom = atom<string>('calc(100vh - 365px)')
