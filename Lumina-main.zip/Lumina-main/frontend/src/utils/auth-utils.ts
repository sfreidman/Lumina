import { User } from 'oidc-client-ts'
import { AuthContextProps } from 'react-oidc-context'

export const getAuthUserFromStorage = () => {
  const oidcStorage = localStorage.getItem(
    `oidc.user:${import.meta.env.VITE_SSO_AUTHORITY}:${import.meta.env.VITE_SSO_CLIENT_ID}`,
  )
  if (!oidcStorage) {
    return null
  }

  return User.fromStorageString(oidcStorage)
}

export const saveLocationAndRedirectToLogin = async (auth: AuthContextProps) => {
  localStorage.setItem('beforeRedirect', window.location.pathname)
  auth.signinRedirect()
}

export const redirectToPreviousLocationAfterLogin = () => {
  window.history.replaceState({}, document.title, window.location.pathname)
  const beforeRedirect = localStorage.getItem('beforeRedirect')
  localStorage.removeItem('beforeRedirect')
  if (beforeRedirect) {
    window.location.href = beforeRedirect
  }
}
