/**
 * Converts a Python timestamp to a JavaScript Date object
 * @param timestamp Python timestamp in seconds
 * @returns JS Date object
 */
export const pythonTimestampToJsDate = (timestamp: number) => {
  return new Date(timestamp * 1000) // JavaScript uses milliseconds, so multiply by 1000
}

/**
 * Cleans up a list of objects by removing null values
 * @param objs List of objects to sanitize
 * @returns Sanitized list of objects with null values removed
 */
export const listSanitizer = <T>(objs: T[]) => {
  return objs.map((obj) => objectSanitizer(obj) as T)
}

/**
 * Cleams up an object by removing null values
 * @param obj Object to sanitize
 * @returns Sanitized object with null values removed
 */
export const objectSanitizer = <T>(obj: T) => {
  const sanitized: any = {}
  for (const key in obj) {
    const keyAs = key as keyof T
    if (Object.prototype.hasOwnProperty.call(obj, key) && obj[keyAs] !== null) {
      sanitized[keyAs] = obj[keyAs]
    }
  }
  return sanitized
}

/**
 * Capitalizes the first letter of a string
 * @param string String to capitalize
 * @returns String with the first letter capitalized
 */
export const capitalizeFirstLetter = (str: string) => {
  return str.charAt(0).toUpperCase() + str.slice(1)
}

/**
 * // Get time difference btween 2 dates
 * @param startDate Start date
 * @param endDate End date
 * @returns Time difference between the 2 dates in hours, minutes, and seconds
 */
export const getDiffDuration = (startDate: Date, endDate: Date) => {
  const diff = Number(endDate.getTime() - startDate.getTime()) / 1000 // remove miliseconds

  const h = Math.floor(diff / 3600)
  const m = Math.floor((diff % 3600) / 60)
  const s = Math.floor((diff % 3600) % 60)

  return {
    hours: ('0' + h).slice(-2),
    minutes: ('0' + m).slice(-2),
    seconds: ('0' + s).slice(-2),
  }
}
