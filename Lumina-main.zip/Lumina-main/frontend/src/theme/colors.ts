import { ColorPartial } from '@mui/material/styles/createPalette'

const white: string = '#fff'
const black: string = '#000'

const blue: ColorPartial = {
  50: '#D0E3F9',
  100: '#98ABC1',
  200: '#3d5169',
  300: '#21354d',
  400: '#2a3747',
  700: '#3d7fc9',
}

const grey: ColorPartial = {
  50: '#f5f6fa',
  100: '#dfe3e9',
  200: '#d9dee5',
  300: '#b9b9b9',
  400: '#909193',
  500: '#5f5b5b',
  600: '#818d9f',
  A100: '#dfe3e96d',
  A200: '#989ca04d',
}

const orange: ColorPartial = {
  400: '#FFA500',
  600: '#f53b00',
  700: '#f91616',
}

const green: ColorPartial = {
  600: '#06b050',
  700: '#2c9a44',
}

const purple: ColorPartial = {
  200: '#c1cafc',
  500: '#b737c2',
}

const yellow: ColorPartial = {
  50: '#f2eee2',
  300: '#fbe599',
}

const red: ColorPartial = {
  100: '#ece7ea',
  200: '#f7c5c5',
  500: '#ff0000',
}

export const colors = {
  black,
  white,
  blue,
  grey,
  orange,
  green,
  purple,
  yellow,
  red,
}
