import { BuildStatus } from '../api/enums/build-status'
import { GithubStatus } from '../api/models/pull-request'
import { additionalPalette } from './theme'

export const colorIndicators = {
  [GithubStatus.open]: additionalPalette.indicators.open!,
  [GithubStatus.merged]: additionalPalette.indicators.merged!,
  [BuildStatus.in_progress]: additionalPalette.indicators.in_progress!,
  [BuildStatus.aborted]: additionalPalette.indicators.aborted!,
  [BuildStatus.success]: additionalPalette.indicators.success!,
  [BuildStatus.failure]: additionalPalette.indicators.failure!,
  [BuildStatus.unstable]: additionalPalette.indicators.unstable!,
  [BuildStatus.skipped]: additionalPalette.indicators.skipped!,
  [BuildStatus.scheduled]: additionalPalette.indicators.scheduled!,
}
