import { createTheme } from '@mui/material/styles'
import { colors } from './colors'

// A custom theme for this app
const theme = createTheme({
  typography: {
    fontFamily: ['poppins'].join(','),
  },
  palette: {
    primary: {
      main: '#33475d',
    },
    secondary: {
      main: '#ff341b',
    },
    background: {
      paper: '#e6eaee',
      default: '#eaedf0',
    },
  },
  components: {
    MuiBackdrop: {
      defaultProps: {
        style: {
          backgroundColor: 'rgba(0, 0, 0, 0.2)',
        },
      },
    },
  },
})

export const additionalPalette = {
  danger: {
    main: colors.red[200],
    secondary: colors.red[100],
  },
  warning: {
    main: colors.yellow[300],
    secondary: colors.yellow[50],
  },
  info: {
    main: colors.grey[100],
    secondary: colors.purple[200],
  },
  prListTitleColor: colors.blue[400],
  prListOpenItemsLabelColor: colors.blue[400],
  prTableTheadColor: colors.white,
  prTableTheadBgColor: colors.grey[600],
  prTableBodyRowBgColor: colors.grey[50],
  prTableTheadHoverBgColor: colors.grey['A200'],
  prTableBodyCellColor: colors.blue[400],
  prDetailsTitleColor: colors.blue[700],
  autoCompleteInputBorderColor: colors.blue[100],
  textFieldInputBorderColor: colors.blue[100],
  notificationAsterixColor: colors.orange[700],
  prLabelsPopupBorder: colors.grey[600],
  prTableTitleCellTitleColor: colors.grey[500],
  prTableTitleCellSubtitleColor: colors.grey[500],
  rootBackdropColor: colors.white,
  leftDrawerListItemActiveLeftBorderColor: colors.orange[600],
  leftDrawerListItemReportBugButtonColor: colors.grey[50],
  leftDrawerListItemReportBugIconColor: colors.grey[50],
  buildRunItemBgColor: colors.grey[50],
  buildRunItemSubTitleColor: colors.grey[500],
  buildRunItemNotValidatedBgColor: colors.grey[200],
  buildRunItemNotValidatedBorderColor: colors.black,
  prDetailsTitleBgColor: colors.grey[100],
  prDetailsSubTitleBgColor: colors.grey['A100'],
  prDetailsSubTitleColor: colors.grey[300],
  prDetailsSubTitleEmphasizeColor: colors.blue[300],
  relatedBuildItemBgColor: colors.blue[50],
  jenkinsRunTitleColor: colors.blue[300],
  jenkinsRunSelectedRunTitleColor: colors.blue[300],
  stagesRunSummaryRunStatusColor: colors.blue[700],
  fancySummaryButtonColor: colors.grey[400],
  stageDetailsDrawerBgColor: colors.grey[100],
  stageDetailsDrawerTitleColor: colors.blue[700],
  stageDetailsDrawerLineBgColor: colors.blue[100],
  errorNotificationBgColor: colors.red[500],
  errorNotificationColor: colors.white,
  indicators: {
    open: colors.green[600]!,
    merged: colors.purple[500]!,
    in_progress: colors.blue[700]!,
    aborted: colors.grey[300]!,
    abortedSecondary: colors.grey[500]!,
    skipped: colors.grey[300]!,
    success: colors.green[700]!,
    failure: colors.orange[700]!,
    unstable: colors.orange[400]!,
    scheduled: colors.blue[100]!,
  },
  white: colors.white!,
  black: colors.black!,
  defaultBoxShadow:
    '0px 2px 4px -1px rgba(0,0,0,0.2), 0px 4px 5px 0px rgba(0,0,0,0.14), 0px 1px 10px 0px rgba(0,0,0,0.12)',
}

export default theme
