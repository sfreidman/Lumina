import { Box } from '@mui/material'
import { useMemo } from 'react'
import { BuildStatus } from '../../api/enums/build-status'
import { StageUI } from '../../api/models/stage'

interface StageTitleCellProps {
  stage: StageUI
  level: number
}

function accumulateFailedItems(items: StageUI[]): number {
  return items.reduce((acc, item: StageUI) => {
    const children = item.children
    if (children.length > 0) {
      return acc + accumulateFailedItems(children)
    } else {
      const add = item.stage_status === BuildStatus.failure || item.stage_status === BuildStatus.unstable ? 1 : 0
      return acc + add
    }
  }, 0)
}

export const StageTitleCell = ({ stage, level }: StageTitleCellProps) => {
  const failedChildrenStages = useMemo(() => accumulateFailedItems(stage.children), [stage])

  return (
    <Box marginLeft={level}>
      {stage.stage_name}{' '}
      {stage.children.length > 0 && (
        <Box component={'span'}>
          (
          {failedChildrenStages > 0 && (
            <Box component={'span'}>
              <Box component={'span'} color={(theme) => theme.palette.secondary.main}>
                {failedChildrenStages}
              </Box>
              /
            </Box>
          )}
          {stage.children.length})
        </Box>
      )}
    </Box>
  )
}
