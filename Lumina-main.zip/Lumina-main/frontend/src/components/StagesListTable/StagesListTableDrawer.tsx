import HighlightOffIcon from '@mui/icons-material/HighlightOff'
import { Box, Divider, Drawer, Stack } from '@mui/material'
import { StageUI } from '../../api/models/stage'
import { additionalPalette } from '../../theme/theme'
import { StageStatusCell } from './StageStatusCell'

interface StagesListTableDrawerProps {
  isOpen: boolean
  onClose: () => void
  stage: StageUI | null
}

export const StagesListTableDrawer = ({ isOpen, onClose, stage }: StagesListTableDrawerProps) => {
  return (
    <Drawer
      open={isOpen}
      onClose={onClose}
      anchor={'right'}
      sx={{
        zIndex: 1201,
        '& .MuiDrawer-paper': {
          width: 650,
          bgcolor: additionalPalette.stageDetailsDrawerBgColor,
          boxShadow: additionalPalette.defaultBoxShadow,
        },
      }}
    >
      <Box>
        <Box p={3} position={'relative'}>
          <Box color={additionalPalette.stageDetailsDrawerTitleColor} textAlign={'center'}>
            {stage?.stage_name}
          </Box>
          <HighlightOffIcon onClick={onClose} sx={{ position: 'absolute', top: 5, right: 5, cursor: 'pointer' }} />
          <Divider sx={{ bgcolor: additionalPalette.stageDetailsDrawerLineBgColor, my: 2 }} />
          <Box display={'flex'} flexDirection={'row'} fontSize={14} px={3} py={1}>
            <Stack spacing={1} alignSelf={'flex-start'}>
              <Box>Device</Box>
              <Box>Status</Box>
              {stage?.exit_code ? <Box>Exit code</Box> : ''}
              {stage?.board_label ? <Box>Board label name</Box> : ''}
              <Box>Start time</Box>
              <Box>End time</Box>
              {stage?.tries.length ? <Box>Number of tries</Box> : ''}
            </Stack>
            <Stack spacing={1} ml={'auto'}>
              <Box textTransform={'capitalize'}>{stage?.platform || 'none'}</Box>
              <Box>
                {stage && (
                  <StageStatusCell
                    stage={stage}
                    indicatorDimensions={{ height: 12, width: 13 }}
                    showDescription={false}
                  />
                )}
              </Box>
              {stage?.exit_code ? <Box>{`${stage.exit_code}-${stage.exit_code_description}`}</Box> : ''}
              {stage?.board_label ? <Box>{`${stage.board_label}`}</Box> : ''}
              <Box>
                {stage?.start_time.toLocaleDateString()} {stage?.start_time.toLocaleTimeString()}
              </Box>
              <Box>
                {stage?.end_time.toLocaleDateString()} {stage?.end_time.toLocaleTimeString()}
              </Box>
              {stage?.tries.length ? <Box>{stage?.tries.length} </Box> : ''}
            </Stack>
          </Box>
          {stage?.tries.map((tryItem, ind) => (
            <Box key={tryItem.try_id} fontSize={14} my={2}>
              <Box fontWeight={500} mb={0.5}>
                Try {ind + 1}
              </Box>
              <Box
                display={'flex'}
                flexDirection={'row'}
                px={3}
                py={1}
                bgcolor={(theme) => theme.palette.background.default}
              >
                <Stack spacing={1} alignSelf={'flex-start'}>
                  <Box>BAS Allocation Id</Box>
                  <Box>Board ip</Box>
                  <Box>Exit code</Box>
                  <Box>Alloc start time</Box>
                  <Box>Alloc end time</Box>
                </Stack>
                <Stack spacing={1} ml={'auto'}>
                  <Box>{tryItem.allocation_id || 'none'}</Box>
                  <Box>{tryItem.board_ip || 'none'}</Box>
                  <Box>{tryItem.exit_code || 'none'}</Box>
                  <Box>{tryItem.body_start_time ? tryItem.body_start_time.toLocaleDateString() : 'none'}</Box>
                  <Box>{tryItem.body_end_time ? tryItem.body_end_time.toLocaleDateString() : 'none'}</Box>
                </Stack>
              </Box>
            </Box>
          ))}
        </Box>
      </Box>
    </Drawer>
  )
}
