import { Box } from '@mui/material'
import { MaterialReactTable, useMaterialReactTable, type MRT_ColumnDef } from 'material-react-table'
import { useState } from 'react'
import { StageStatusType, StageUI } from '../../api/models/stage'
import { additionalPalette } from '../../theme/theme'
import { getDiffDuration } from '../../utils'
import { StageStatusCell } from './StageStatusCell'
import { StageTitleCell } from './StageTitleCell'
import { StagesListTableDrawer } from './StagesListTableDrawer'

interface StagesListTableProps {
  stages: StageUI[]
  isLoading: boolean
  isError: boolean
}

const columns: MRT_ColumnDef<StageUI>[] = [
  {
    accessorKey: 'stage_name',
    header: 'Name',
    grow: 1,
    Cell: ({ row }) => {
      const stage = row.original as StageUI
      return <StageTitleCell stage={stage} level={row.depth} />
    },
  },
  {
    accessorKey: 'stage_status',
    header: 'Stage Status',
    Cell: ({ row }) => {
      const stage = row.original as StageUI
      return <StageStatusCell stage={stage} showDescription={stage.exit_code !== 0} /> // 0 equals "success" - we're not showing if success for now
    },
  },
  {
    accessorKey: 'start_time',
    header: 'Duration',
    grow: 0,
    Cell: ({ row }) => {
      const stage = row.original as StageUI
      const { hours, minutes, seconds } = getDiffDuration(stage.start_time, stage.end_time)
      return (
        stage.type === StageStatusType.STAGE && (
          <Box>
            {Number(hours) > 0 && `${hours} h `}
            {Number(minutes) > 0 && `${minutes} min `}
            {Number(seconds) > 0 && `${seconds} sec`}
            {Number(hours) === 0 && Number(minutes) === 0 && Number(seconds) === 0 && '0 sec'}
          </Box>
        )
      )
    },
  },
  {
    accessorKey: 'platform',
    header: 'Device',
    grow: 0,
    Cell: ({ row }) => {
      const stage = row.original as StageUI
      return (
        stage.type === StageStatusType.STAGE && (
          <Box component={'span'} textTransform={'capitalize'}>
            {stage.platform}
          </Box>
        )
      )
    },
  },
] as const

export const StagesListTable = ({ stages, isLoading, isError }: StagesListTableProps) => {
  const [selectedRow, setSelectedRow] = useState<StageUI | null>(null)
  const drawerOpen = !!selectedRow

  const onClose = () => {
    setSelectedRow(null)
  }

  const table = useMaterialReactTable<StageUI>({
    columns,
    data: stages,
    layoutMode: 'grid',
    enableExpandAll: true,
    enableFilters: false,
    manualFiltering: true, //turn off built-in client-side filtering
    enableTopToolbar: false,
    filterFromLeafRows: true, //apply filtering to all rows instead of just parent rows
    getSubRows: (row) => row.children, //default
    enablePagination: false,
    enableExpanding: true,
    state: {
      isLoading: isLoading,
      showAlertBanner: isError,
      showProgressBars: isLoading,
    },
    muiTablePaperProps: {
      sx: {
        borderRadius: 0,
        boxShadow: 'none',
      },
    },
    muiTableHeadProps: {
      sx: {
        '& .MuiTableRow-head': {
          paddingX: 2,
          bgcolor: additionalPalette.prTableTheadBgColor,
        },
      },
    },
    muiTableHeadCellProps: {
      sx: {
        border: 'none',
        color: additionalPalette.prTableTheadColor,
        fontWeight: 400,
        '& .MuiSvgIcon-root': {
          color: `${additionalPalette.prTableTheadColor} !important`,
        },
        fontSize: 16,
      },
    },
    muiTableBodyRowProps: ({ row }) => ({
      sx: {
        paddingX: 2,
        mt: 0.4,
        backgroundColor: `${additionalPalette.prTableBodyRowBgColor} !important`,
        borderRadius: 2.3,
        cursor: 'pointer',
        '&:hover': {
          bgcolor: `${additionalPalette.prTableTheadHoverBgColor} + !important`,
          '& .MuiTableCell-root': {
            bgcolor: 'initial !important',
            '&:after': {
              bgcolor: 'initial !important',
            },
          },
        },
        boxShadow: selectedRow?.stage_id === row.original.stage_id ? additionalPalette.defaultBoxShadow : 'none',
        borderLeft: (theme) =>
          selectedRow?.stage_id === row.original.stage_id ? `3px solid ${theme.palette.secondary.main}` : 'none',
      },
      onClick: () => {
        if (row.original.type === StageStatusType.STAGE) {
          setSelectedRow(row.original)
        }
      },
    }),
    muiTableBodyCellProps: {
      sx: {
        color: additionalPalette.prTableBodyCellColor,
        fontSize: 16,
        paddingY: 1.5,
        '& .MuiButtonBase-root.Mui-disabled .MuiSvgIcon-root': {
          color: additionalPalette.prTableBodyCellColor,
        },
      },
    },
  })

  // Hack to edit the expand column
  const expandColumn = table.getColumn('mrt-row-expand').columnDef
  expandColumn.grow = 0
  expandColumn.header = ''
  expandColumn.maxSize = 50

  return (
    <>
      <MaterialReactTable table={table} />
      <StagesListTableDrawer stage={selectedRow} isOpen={drawerOpen} onClose={onClose} />
    </>
  )
}
