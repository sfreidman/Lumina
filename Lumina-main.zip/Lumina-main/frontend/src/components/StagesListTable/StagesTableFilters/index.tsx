import { Box } from '@mui/material'
import { useCallback, useEffect, useState } from 'react'
import { BuildStatus } from '../../../api/enums/build-status'
import { StageUI } from '../../../api/models/stage'
import { FancySummaryButton } from '../../FancySummaryButton'
import { FilterAutocomplete } from '../../FilterAutocomplete'
import { FILTER_ACTIONS, Filters, StatusAggregation } from './types'
import { aggregateStagesByStatuses, filterStages } from './utils'

interface StagesTableFiltersProps {
  stages: StageUI[]
  onStagesFiltered: (stages: StageUI[]) => void
}

export const StagesTableFilters = ({ stages, onStagesFiltered }: StagesTableFiltersProps) => {
  const [stagesFiltered, setStagesFiltered] = useState<StageUI[]>(stages)
  const [activeFilters, setActiveFilters] = useState<Filters>({
    [FILTER_ACTIONS.STATUS]: { key: FILTER_ACTIONS.STATUS, value: [] as BuildStatus[] },
    [FILTER_ACTIONS.DEVICE]: { key: FILTER_ACTIONS.DEVICE, value: [] as string[] },
    [FILTER_ACTIONS.NAME]: { key: FILTER_ACTIONS.NAME, value: [] as string[] },
  })
  const [deviceOptions, setDeviceOptions] = useState<string[]>([])
  const [stageNameOptions, setStageNameOptions] = useState<string[]>([])

  const [stagesAggregated, setStagesAggregated] = useState<StatusAggregation>(
    aggregateStagesByStatuses(stages, {} as StatusAggregation),
  )

  const setFilter = useCallback(
    (key: FILTER_ACTIONS, value: string | string[] | BuildStatus, isSelected?: boolean) => {
      let newFilterValue: string | string[] | BuildStatus[]
      const tempAggregated = { ...stagesAggregated }
      const tempActiveFilters = { ...activeFilters }
      switch (key) {
        case FILTER_ACTIONS.STATUS:
          tempAggregated[value as BuildStatus].selected = isSelected!
          newFilterValue = Object.values(tempAggregated)
            .filter((stage) => stage.selected)
            .map((stage) => stage.id) as BuildStatus[]

          setStagesAggregated(tempAggregated)
          break
        case FILTER_ACTIONS.NAME:
          newFilterValue = value
          break
        case FILTER_ACTIONS.DEVICE:
          newFilterValue = value
          break
      }
      tempActiveFilters[key].value = newFilterValue
      setActiveFilters(tempActiveFilters)

      const filteredStages = filterStages(stages, tempActiveFilters)
      setStagesFiltered(filteredStages)
    },
    [activeFilters, stages, stagesAggregated],
  )

  // accumulate all the devices (distinct)
  useEffect(() => {
    function accumulateDevices(stages: StageUI[]) {
      const devices: Set<string> = new Set<string>()
      stages.forEach((stage) => {
        stage.platform && devices.add(stage.platform)
        if (stage.children.length > 0) {
          accumulateDevices(stage.children).forEach((device) => devices.add(device))
        }
      })
      return devices
    }
    const devices = accumulateDevices(stages)
    setDeviceOptions(Array.from(devices))
  }, [stages])

  useEffect(() => {
    function accumulateStageNames(stages: StageUI[]) {
      const stages_names: Set<string> = new Set<string>()
      stages.forEach((stage) => {
        stage.stage_name && stage.type == 'STAGE' && stages_names.add(stage.stage_name)
        if (stage.children.length > 0) {
          accumulateStageNames(stage.children).forEach((stage_name) => stages_names.add(stage_name))
        }
      })
      return stages_names
    }
    const stages_names = accumulateStageNames(stages)
    setStageNameOptions(Array.from(stages_names))
  }, [stages])

  useEffect(() => {
    onStagesFiltered(stagesFiltered)
  }, [stagesFiltered, onStagesFiltered])

  return (
    <Box maxHeight={'100%'}>
      <Box display={'flex'} mb={3}>
        {Object.keys(stagesAggregated).map((key) => (
          <Box mr={2.5} key={key}>
            <FancySummaryButton
              id={stagesAggregated[key as BuildStatus].id}
              summary={stagesAggregated[key as BuildStatus].amount}
              label={stagesAggregated[key as BuildStatus].label}
              color={stagesAggregated[key as BuildStatus].color}
              isSelected={stagesAggregated[key as BuildStatus].selected}
              select={(id, isSelected) => setFilter(FILTER_ACTIONS.STATUS, id as BuildStatus, isSelected)}
            />
          </Box>
        ))}
      </Box>

      <Box mb={1.5} display={'flex'} alignItems={'center'}>
        <Box>Total number of stages ({stages?.length || 0})</Box>
        <Box ml={'auto'} display={'flex'}>
          <Box mr={3}>
            <FilterAutocomplete
              options={deviceOptions}
              filterKey={FILTER_ACTIONS.DEVICE}
              filterValue={(activeFilters[FILTER_ACTIONS.DEVICE].value as string[]).join(',')}
              placeholder="Device"
              onChange={(_e, value) => setFilter(FILTER_ACTIONS.DEVICE, value, false)}
            />
          </Box>
          <Box mr={4}>
            <FilterAutocomplete
              options={stageNameOptions}
              filterKey={FILTER_ACTIONS.NAME}
              filterValue={(activeFilters[FILTER_ACTIONS.NAME].value as string[]).join(',')}
              placeholder="Stage Name"
              onChange={(_e, value) => setFilter(FILTER_ACTIONS.NAME, value, false)}
            />
          </Box>
        </Box>
      </Box>
    </Box>
  )
}
