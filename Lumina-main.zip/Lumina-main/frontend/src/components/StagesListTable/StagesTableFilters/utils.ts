import { BuildStatus } from '../../../api/enums/build-status'
import { StageStatusType, StageUI } from '../../../api/models/stage'
import { colorIndicators } from '../../../theme/color-indicators'
import { additionalPalette } from '../../../theme/theme'
import { capitalizeFirstLetter } from '../../../utils'
import { Filters, StatusAggregation } from './types'

export const getLabelFromBuildStatus = (status: BuildStatus) => {
  switch (status) {
    case BuildStatus.success:
      return 'Passed'
    case BuildStatus.failure:
      return 'Failed'
    case BuildStatus.aborted:
      return 'Aborted'
    case BuildStatus.skipped:
      return 'Skipped'
    case BuildStatus.in_progress:
      return 'In Progress'
    default:
      return capitalizeFirstLetter(status)
  }
}

export const aggregateStagesByStatuses = (
  stages: StageUI[],
  aggregatedStatuses: StatusAggregation = {} as StatusAggregation,
) => {
  stages.forEach((stage) => {
    const key = stage.stage_status
    if (!aggregatedStatuses[key]) {
      aggregatedStatuses[key] = {
        id: stage.stage_status,
        label: getLabelFromBuildStatus(stage.stage_status),
        color: key !== BuildStatus.aborted ? colorIndicators[key] : additionalPalette.indicators.abortedSecondary,
        amount: 1,
        selected: false,
      }
    } else {
      aggregatedStatuses[key].amount++
    }
    if (stage.children.length > 0) {
      aggregateStagesByStatuses(stage.children, aggregatedStatuses)
    }
  })
  return aggregatedStatuses
}

export function filterStages(stages: StageUI[], filters: Filters): StageUI[] {
  const { STATUS, DEVICE, NAME } = filters
  const statuses = STATUS.value as BuildStatus[]
  const devices = DEVICE.value as string[]
  const name = NAME.value as string[]
  return (
    stages.reduce<StageUI[]>((acc, item: StageUI) => {
      const children = item.children
      let passedFilters = true
      if (item.type !== StageStatusType.STAGE) {
        // wrapper type
        const temp = { ...item }
        temp.children = filterStages(children, filters)
        if (temp.children.length > 0) {
          acc.push(temp)
          return acc
        }
      } else {
        // stage type
        if (statuses && statuses.length > 0 && !statuses.includes(item.stage_status)) {
          passedFilters = false
        }
        if (devices && devices.length > 0 && !devices.includes(item.platform)) {
          passedFilters = false
        }
        if (name && name.length > 0 && !name.includes(item.stage_name)) {
          passedFilters = false
        }
        if (passedFilters) {
          const temp = { ...item }
          acc.push(temp)
          if (children.length > 0) {
            temp.children = filterStages(children, filters)
          }
        }
        return acc
      }
      return acc
    }, [] as StageUI[]) || []
  )
}
