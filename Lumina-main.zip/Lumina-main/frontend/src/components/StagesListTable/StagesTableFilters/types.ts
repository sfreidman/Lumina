import { BuildStatus } from '../../../api/enums/build-status'
import { KeyValue } from '../../../models/key-value'

export type StatusAggregation = {
  [key in BuildStatus]: { id: BuildStatus; label: string; color: string; amount: number; selected: boolean }
}

export enum FILTER_ACTIONS {
  STATUS = 'STATUS',
  NAME = 'NAME',
  DEVICE = 'DEVICE',
}

export type Filters = Record<FILTER_ACTIONS, KeyValue<FILTER_ACTIONS, BuildStatus[] | string[] | string>>
