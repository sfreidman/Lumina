import { Box } from '@mui/material'
import { BuildStatus } from '../../api/enums/build-status'
import { StageStatusType, StageUI } from '../../api/models/stage'
import { colorIndicators } from '../../theme/color-indicators'
import { capitalizeFirstLetter } from '../../utils'
import { ColorIndicatorLabel } from '../ColorIndicatorLabel'

interface StageStatusCellProps {
  stage: StageUI
  indicatorDimensions?: { height: number; width: number }
  showDescription: boolean
}

export const StageStatusCell = ({ stage, showDescription, indicatorDimensions }: StageStatusCellProps) => {
  const statusLabel = (status: BuildStatus) => {
    switch (status) {
      case BuildStatus.success:
        return 'Passed'
      case BuildStatus.failure:
        return 'Failed'
      case BuildStatus.aborted:
        return 'Aborted'
      case BuildStatus.skipped:
        return 'Skipped'
      default:
        return capitalizeFirstLetter(stage.stage_status)
    }
  }
  const color = colorIndicators[stage.stage_status as keyof typeof colorIndicators]

  return stage.type === StageStatusType.STAGE ? (
    <Box display={'flex'} justifyContent={'center'} flexDirection={'column'}>
      <Box>
        {stage.stage_status && (
          <ColorIndicatorLabel
            color={color}
            label={statusLabel(stage.stage_status) || ''}
            dimensions={indicatorDimensions}
          />
        )}
        {stage.exit_code_description && showDescription && (
          <Box component={'span'} fontSize={12}>
            ({stage.exit_code}-{stage.exit_code_description})
          </Box>
        )}
      </Box>
      <Box>
        {stage.num_pass_tests > 0 && (
          <Box component={'span'} color={'success.main'}>
            {stage.num_pass_tests} passed &nbsp;
          </Box>
        )}

        {stage.num_failed_tests > 0 && (
          <Box component={'span'} color={'error.main'}>
            {stage.num_failed_tests} failed &nbsp;
          </Box>
        )}
        {stage.num_skipped_tests > 0 && (
          <Box component={'span'} color={'grey'}>
            {stage.num_skipped_tests} skipped
          </Box>
        )}
      </Box>
    </Box>
  ) : (
    <></>
  )
}
