import { Box } from '@mui/material'

interface ColorIndicatorLabelProps {
  color: string
  label: string
  onClick?: () => void
  dimensions?: { height: number; width: number }
}

export const ColorIndicatorLabel = ({
  color,
  label,
  onClick,
  dimensions = { height: 20, width: 23 },
}: ColorIndicatorLabelProps) => {
  return (
    <Box display={'flex'} alignItems={'center'}>
      {/* Attach the onClick handler to this Box to make the color box clickable */}
      <Box
        height={dimensions.height}
        width={dimensions.width}
        bgcolor={color}
        mr={1}
        borderRadius={1.3}
        sx={{ cursor: 'pointer' }}
        onClick={onClick}
      />
      <Box sx={{ cursor: 'pointer' }} textTransform={'capitalize'} onClick={onClick}>
        {label}
      </Box>
    </Box>
  )
}
