import { Autocomplete, Box, Checkbox, Popper, TextField } from '@mui/material'
import { useMemo } from 'react'
import { additionalPalette } from '../theme/theme'

interface FilterAutocompleteProps {
  options: string[]
  filterKey: string
  placeholder: string
  filterValue: string
  onChange?: (e: string, value: string[]) => void
  width?: number
}

const filterPlaceholderStyle = {
  input: {
    '&::placeholder': {
      opacity: 1,
    },
  },
}

export const FilterAutocomplete = ({
  options,
  filterKey,
  placeholder,
  filterValue,
  onChange,
  width = 220,
}: FilterAutocompleteProps) => {
  // Creates a copy of options and sorts it based on the filterValue, having filterValue options first
  const { sortedOptions, filtersLength, hasFilters } = useMemo(() => {
    if (!filterValue) return { sortedOptions: options, filtersLength: 0, hasFilters: false }

    const filterValueSet = new Set(filterValue.split(','))
    const filtersLength = filterValueSet.size
    const hasFilters = filtersLength > 0

    const sortedOptions = options.toSorted((a, b) => {
      if (filterValueSet.has(a) && !filterValueSet.has(b)) {
        return -1
      }
      if (!filterValueSet.has(a) && filterValueSet.has(b)) {
        return 1
      }
      return 0
    })
    return { sortedOptions, filtersLength, hasFilters }
  }, [options, filterValue])

  return (
    <Box position={'relative'}>
      <Autocomplete
        options={sortedOptions}
        sx={{
          width,
          '& .MuiOutlinedInput-notchedOutline': { borderColor: additionalPalette.autoCompleteInputBorderColor },
          '& .MuiAutocomplete-inputRoot': { borderRadius: '5px', paddingY: 0.2 },
          '& .MuiAutocomplete-input': { py: '3px !important' },
        }}
        renderInput={(params) => (
          <TextField
            placeholder={`${placeholder} ${hasFilters ? `(${filtersLength})` : ''}`}
            variant="standard"
            {...params}
            sx={hasFilters ? filterPlaceholderStyle : {}}
          />
        )}
        renderTags={() => null}
        multiple
        onChange={(_e, newValue) => newValue && onChange && onChange(filterKey, newValue)}
        renderOption={(props, option, { selected }) => (
          <li {...props}>
            <Checkbox style={{ marginRight: 8 }} checked={selected} />
            <Box>{option}</Box>
          </li>
        )}
        PopperComponent={(props) => <Popper {...props} style={{ width: 'fit-content' }} placement="bottom-start" />}
      />
    </Box>
  )
}
