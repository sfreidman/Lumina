import { Tab, styled } from '@mui/material'

export const NotCapitalizedTab = styled(Tab)({
  '&.MuiTab-root': { textTransform: 'none' },
  fontSize: 16,
  minWidth: '270px',
})

export const SecondryNotCapitalizedTab = styled(Tab)<{ $selected: boolean }>(({ $selected }) => ({
  '&.MuiTab-root': { textTransform: 'none' },
  fontSize: 16,
  minWidth: '270px',
  backgroundColor: $selected ? 'green' : 'grey',
}))
