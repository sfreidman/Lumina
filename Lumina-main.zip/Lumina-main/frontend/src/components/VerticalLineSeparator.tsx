import Box from '@mui/material/Box'

interface VerticalLineSeparatorProps {
  height: string
  bgColor: string
}

export const VerticalLineSeparator = ({ bgColor, height }: VerticalLineSeparatorProps) => {
  return <Box display={'inline-block'} bgcolor={bgColor} height={height} width={'1px'} mx={1}></Box>
}
