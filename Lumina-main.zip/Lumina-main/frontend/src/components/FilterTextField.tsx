import { Search } from '@mui/icons-material'
import { Box, InputAdornment, TextField } from '@mui/material'
import { debounce } from '@mui/material/utils'
import { additionalPalette } from '../theme/theme'

interface FilterTextFieldProps {
  placeholder: string
  onChange?: (value: string) => void
}

export const FilterTextField = ({ placeholder, onChange }: FilterTextFieldProps) => {
  return (
    <Box position={'relative'}>
      <TextField
        placeholder={placeholder}
        variant="standard"
        sx={{
          width: 200,
          '& .MuiOutlinedInput-notchedOutline': { borderColor: additionalPalette.textFieldInputBorderColor },
          '& .MuiOutlinedInput-root': { borderRadius: '5px' },
          '& .MuiOutlinedInput-input': { paddingY: '4px' },
        }}
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <Search />
            </InputAdornment>
          ),
        }}
        onChange={debounce((e) => {
          onChange && onChange(e.target.value)
        }, 500)}
      />
    </Box>
  )
}
