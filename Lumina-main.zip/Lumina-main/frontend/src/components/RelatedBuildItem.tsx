import { Box, Theme, Tooltip } from '@mui/material'
import { useMemo } from 'react'
import TimeAgo from 'react-timeago'
import { RelatedBuildUI } from '../api/models/build-runs'
import { colorIndicators } from '../theme/color-indicators'
import { additionalPalette } from '../theme/theme'
import { capitalizeFirstLetter } from '../utils'

interface RelatedBuildItemProps {
  build: RelatedBuildUI
  maxHeight?: string | number
  selected: boolean
  disabled: boolean
  onSelect: () => void
}

export const RelatedBuildItem = ({ build, maxHeight = 28, selected, disabled, onSelect }: RelatedBuildItemProps) => {
  const status = useMemo(() => {
    const statusTransformed = build.build_status === 'in_progress' ? 'running' : build.build_status
    return capitalizeFirstLetter(statusTransformed)
  }, [build.build_status])

  return (
    <Box
      display={'flex'}
      alignItems={'center'}
      bgcolor={additionalPalette.relatedBuildItemBgColor}
      height={maxHeight}
      maxHeight={maxHeight}
      overflow={'auto'}
      borderRadius={2.3}
      borderLeft={(theme: Theme) => (selected ? `5px solid ${theme.palette.secondary.main}` : '3px solid transparent')}
      px={1.5}
      mb={0.5}
      fontSize={14}
      sx={{ cursor: disabled ? 'default' : 'pointer' }}
      onClick={() => !disabled && onSelect()}
    >
      <Tooltip title={status}>
        <Box bgcolor={colorIndicators[build.build_status]} height={15} width={15} borderRadius={'50%'} mr={2}></Box>
      </Tooltip>
      <Box mr={1}>#{build.build_run_id}</Box>
      <Box>
        <TimeAgo date={build.start_time} />
      </Box>
    </Box>
  )
}
