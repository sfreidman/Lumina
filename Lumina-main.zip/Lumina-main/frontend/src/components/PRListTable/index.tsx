import Box from '@mui/material/Box'
import { Updater } from '@tanstack/react-query'
import { useNavigate } from '@tanstack/react-router'
import {
  MRT_PaginationState,
  MRT_SortingState,
  MaterialReactTable,
  useMaterialReactTable,
  type MRT_ColumnDef,
} from 'material-react-table'
import { BuildStatus } from '../../api/enums/build-status'
import { PullRequestLabel, PullRequestUI } from '../../api/models/pull-request'
import { colorIndicators } from '../../theme/color-indicators'
import { additionalPalette } from '../../theme/theme'
import { ColorIndicatorLabel } from '../ColorIndicatorLabel'
import { PRTableLabelCell } from './PRTableLabelCell'
import { PRTableTitleCell } from './PRTableTitleCell'

const columns: MRT_ColumnDef<PullRequestUI>[] = [
  {
    accessorKey: 'title',
    header: 'Pull request',
    grow: 1,
    minSize: 350,
    Cell: ({ row }) => {
      const pr = row.original as PullRequestUI
      return <PRTableTitleCell pr={pr} />
    },
  },
  {
    accessorKey: 'target_branch',
    header: 'Target Branch',
    maxSize: 150,
  },
  {
    accessorKey: 'pr_labels',
    header: 'Labels',
    enableSorting: false,
    maxSize: 150,
    Cell: ({ cell }) => {
      const labels = cell.getValue<PullRequestLabel[]>()
      return labels.length ? (
        <PRTableLabelCell labels={labels} maxLabelsDisplay={2} maxLabelWidth={'150px'} />
      ) : (
        <Box></Box>
      )
    },
  },
  {
    accessorKey: 'github_status',
    header: 'Github',
    grow: 0,
    maxSize: 150,
    Cell: ({ cell, row }) => {
      const state = cell.getValue<string>()
      const pr = row.original as PullRequestUI
      const color = colorIndicators[state as keyof typeof colorIndicators]
      return (
        state && (
          <ColorIndicatorLabel color={color} label={state} onClick={() => window.open(pr.github_link, '_blank')} />
        )
      )
    },
  },
  {
    accessorKey: 'latest_build_status',
    header: 'Latest Jenkins Run',
    grow: 0,
    maxSize: 150,
    Cell: ({ cell, row }) => {
      const state = cell.getValue<string>()
      let label = state
      if (state === BuildStatus.in_progress) {
        label = 'Running'
      }
      const pr = row.original as PullRequestUI
      const color = colorIndicators[state as keyof typeof colorIndicators]
      return (
        state && (
          <ColorIndicatorLabel color={color} label={label} onClick={() => window.open(pr.latest_build_url, '_blank')} />
        )
      )
    },
  },
] as const

interface PRListTableProps {
  data: PullRequestUI[]
  isLoading: boolean
  isError: boolean
  totalCount: number
  sorting: MRT_SortingState
  setSorting: (updaterOrValue: Updater<MRT_SortingState, MRT_SortingState>) => void
  pagination: MRT_PaginationState
  setPagination: (updaterOrValue: Updater<MRT_PaginationState, MRT_PaginationState>) => void
}
const tHeadTextColor = additionalPalette.prTableTheadColor

export const PRListTable = ({
  data,
  totalCount,
  isLoading,
  isError,
  sorting,
  setSorting,
  pagination,
  setPagination,
}: PRListTableProps) => {
  const navigate = useNavigate()

  const table = useMaterialReactTable<PullRequestUI>({
    columns,
    data,
    layoutMode: 'grid',
    initialState: { showColumnFilters: false },
    manualFiltering: true, //turn off built-in client-side filtering
    enableFilters: false,
    enableTopToolbar: false,
    columnFilterDisplayMode: 'custom',
    manualPagination: true, //turn off built-in client-side pagination
    manualSorting: true, //turn off built-in client-side sorting
    muiToolbarAlertBannerProps: isError
      ? {
          color: 'error',
          children: 'Error loading data',
        }
      : undefined,
    onSortingChange: setSorting,
    onPaginationChange: setPagination,
    rowCount: totalCount,
    state: {
      isLoading: isLoading,
      pagination,
      showAlertBanner: isError,
      showProgressBars: isLoading,
      sorting,
    },
    muiTablePaperProps: {
      sx: {
        borderRadius: 0,
        boxShadow: 'none',
      },
    },
    muiTableHeadProps: {
      sx: {
        '& .MuiTableRow-head': {
          paddingX: 2,
          paddingY: 1,
          bgcolor: additionalPalette.prTableTheadBgColor,
        },
      },
    },
    muiTableHeadCellProps: {
      sx: {
        border: 'none',
        color: tHeadTextColor,
        fontWeight: 400,
        '& .MuiSvgIcon-root': {
          color: `${tHeadTextColor} !important`,
        },
        fontSize: 16,
      },
    },
    muiTableBodyRowProps: ({ row }) => ({
      onClick: () => {
        const pr = row.original as PullRequestUI
        if (pr.latest_build_sha && pr.latest_build_run_id !== undefined) {
          navigate({
            to: '/pull-requests/$prId/jenkins-runs/$buildSha/$buildId/stages-run-summary',
            params: {
              prId: pr.id.toString(),
              buildSha: pr.latest_build_sha.substring(0, 7) || 'none',
              buildId: pr.latest_build_run_id?.toString() || 'none',
            },
          })
        } else {
          navigate({
            to: '/pull-requests/$prId/new-jenkins-run',
            params: {
              prId: pr.id.toString(),
            },
          })
        }
      },
      sx: {
        paddingX: 2,
        mt: 0.4,
        backgroundColor: `${additionalPalette.prTableBodyRowBgColor} !important`,
        borderRadius: 2.3,
        '&:hover': {
          bgcolor: `${additionalPalette.prTableTheadHoverBgColor} + !important`,
          '& .MuiTableCell-root': {
            bgcolor: 'initial !important',
            '&:after': {
              bgcolor: 'initial !important',
            },
          },
        },
      },
    }),
    muiTableBodyCellProps: {
      sx: {
        color: additionalPalette.prTableBodyCellColor,
        fontSize: 16,
        paddingY: 1.5,
      },
    },
  })

  return (
    <Box height={'100%'} width={'100%'}>
      <MaterialReactTable table={table} />
    </Box>
  )
}
