import { Unstable_Popup as BasePopup } from '@mui/base/Unstable_Popup'
import { Box, Tooltip } from '@mui/material'
import { useState } from 'react'
import { PullRequestLabel } from '../../api/models/pull-request'
import theme, { additionalPalette } from '../../theme/theme'
import { PRLabel } from './PRLabel'

interface PRTableLabelCellProps {
  labels: PullRequestLabel[]
  maxLabelsDisplay: number
  maxLabelWidth?: string
}

const popupBackgroundColor = theme.palette.grey[100]

export const PRTableLabelCell = ({ labels, maxLabelsDisplay, maxLabelWidth }: PRTableLabelCellProps) => {
  const [anchor, setAnchor] = useState<null | HTMLElement>(null)

  const toggleMore = (event: React.MouseEvent<HTMLElement>) => {
    setAnchor(anchor ? null : event.currentTarget)
  }

  const open = Boolean(anchor)

  return (
    <Box display={'flex'} alignItems={'center'} flexWrap={'wrap'}>
      {labels.map(
        (label, index) =>
          index < maxLabelsDisplay && (
            <Tooltip key={label.name} title={label.name}>
              <Box mr={0.5} mb={0.5}>
                <PRLabel label={label.name} bgColor={label.color} maxWidth={maxLabelWidth} />
              </Box>
            </Tooltip>
          ),
      )}
      {labels.length > maxLabelsDisplay && (
        <Box
          onMouseEnter={toggleMore}
          onMouseLeave={() => setAnchor(null)}
          sx={{ cursor: 'pointer', fontSize: '12px', mb: 0.5 }}
        >
          +{labels.length - maxLabelsDisplay}
        </Box>
      )}
      <BasePopup open={open} anchor={anchor}>
        <Box
          bgcolor={popupBackgroundColor}
          p={1}
          border={`1px solid ${additionalPalette.prLabelsPopupBorder}`}
          borderRadius={3}
        >
          {labels.map(
            (label, index) =>
              index > maxLabelsDisplay - 1 && (
                <Tooltip key={label.name} title={label.name}>
                  <Box m={0.2}>
                    <PRLabel label={label.name} bgColor={label.color} />
                  </Box>
                </Tooltip>
              ),
          )}
        </Box>
      </BasePopup>
    </Box>
  )
}
