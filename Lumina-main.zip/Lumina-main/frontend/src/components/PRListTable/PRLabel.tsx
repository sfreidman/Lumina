import { useMemo } from 'react'
import { BoxTextOverflow } from '../BoxTextOverfolw'

interface PRLabelProps {
  label: string
  bgColor: string
  maxWidth?: string
}

export const PRLabel = ({ label, bgColor, maxWidth }: PRLabelProps) => {
  const backgroundColor = useMemo(() => (bgColor.includes('#') ? bgColor : `#${bgColor}`), [bgColor])
  return (
    <BoxTextOverflow
      bgcolor={`${backgroundColor}3d`}
      borderRadius={2}
      px={0.8}
      py={0.3}
      maxWidth={maxWidth ?? 'fit-content'}
      fontSize={12}
    >
      {label}
    </BoxTextOverflow>
  )
}
