import { Box, Tooltip } from '@mui/material'
import { useMemo } from 'react'
import TimeAgo from 'react-timeago'
import { PROwnerRole, PullRequestUI } from '../../api/models/pull-request'
import { additionalPalette } from '../../theme/theme'
import { BoxTextOverflow } from '../BoxTextOverfolw'

interface PRTableTitleCellProps {
  pr: PullRequestUI
}

export function PRTableTitleCell({ pr }: PRTableTitleCellProps) {
  const owner = useMemo(() => pr.pr_owners.find((owner) => owner.role === PROwnerRole.AUTHOR), pr.pr_owners)
  const assinees = useMemo(() => pr.pr_owners.filter((owner) => owner.role === PROwnerRole.ASSIGNEE), pr.pr_owners)
  return (
    <Box maxWidth={'100%'}>
      <Tooltip title={`${pr.title} #${pr.id}`}>
        <Box display="flex" fontSize="16px" maxWidth="100%">
          {/* Title with truncation */}
          <BoxTextOverflow flexGrow={1} minWidth={0}>
            {pr.title}
          </BoxTextOverflow>
          {/* PR ID always visible, with a space before it */}
          <Box whiteSpace="nowrap">
            {' #'}
            {pr.id}
          </Box>
        </Box>
      </Tooltip>
      <Box fontSize={14} color={additionalPalette.prTableTitleCellTitleColor}>
        created by {owner?.user_name} | &nbsp;
        <TimeAgo date={pr.latest_commit} />
      </Box>
      <Box fontSize={14} color={additionalPalette.prTableTitleCellSubtitleColor}>
        {assinees.length > 0 && (
          <Box>
            Assigned to:{' '}
            {assinees.map((assignee, index) => (
              <Box key={assignee.user_name} component={'span'}>
                {assignee.user_name}
                {index < assinees.length - 1 && ', '}
              </Box>
            ))}
          </Box>
        )}
      </Box>
    </Box>
  )
}
