import { Box } from '@mui/material'
import { useCallback } from 'react'
import { PrFilters } from '../../api/models/pull-request'
import { StringMap } from '../../models/string-map'
import { FilterAutocomplete } from '../FilterAutocomplete'
import { FilterTextField } from '../FilterTextField'

interface PRListTableFiltersProps {
  filters: PrFilters
  currentFilters: Record<string, string>
  onFiltersChange: (filters: StringMap) => void
}

export enum FilterKeys {
  TargetBranch = 'target_branch',
  Label = 'label',
  Owner = 'owner',
  PRID = 'pr_id',
  Title = 'title',
}

export const PRListTableFilters = ({ filters, currentFilters, onFiltersChange }: PRListTableFiltersProps) => {
  const updateFilters = (key: string, value: string[]) => {
    const filtersUpdate = { ...currentFilters }
    if (value.length > 0) {
      filtersUpdate[key] = value.join(',')
    } else {
      delete filtersUpdate[key]
    }
    if (filtersUpdate[FilterKeys.PRID]) {
      delete filtersUpdate[FilterKeys.PRID]
    }
    onFiltersChange(filtersUpdate)
  }

  const searchByPRID = useCallback((id: string) => {
    if (id !== '') {
      onFiltersChange({ [FilterKeys.PRID]: id })
    } else {
      onFiltersChange({})
    }
  }, [])

  const searchByTitle = useCallback((value: string) => {
    const filtersUpdate = { ...currentFilters }
    if (value !== '') {
      onFiltersChange({ [FilterKeys.Title]: value, ...filtersUpdate })
    } else {
      delete filtersUpdate[FilterKeys.Title]
      onFiltersChange(filtersUpdate)
    }
  }, [])

  return (
    <Box display={'flex'} flexGrow={1}>
      <Box mr={3}>
        <FilterTextField placeholder="Title" onChange={searchByTitle} />
      </Box>
      <Box mr={3} sx={{ position: 'relative' }}>
        <FilterAutocomplete
          options={filters.target_branches}
          filterKey={FilterKeys.TargetBranch}
          filterValue={currentFilters[FilterKeys.TargetBranch]}
          placeholder="Target Branch"
          onChange={updateFilters}
        />
      </Box>
      <Box mr={3} sx={{ position: 'relative' }}>
        <FilterAutocomplete
          options={filters.labels}
          filterKey={FilterKeys.Label}
          filterValue={currentFilters[FilterKeys.Label]}
          placeholder="Label"
          onChange={updateFilters}
        />
      </Box>
      <Box mr={3} sx={{ position: 'relative' }}>
        <FilterAutocomplete
          options={filters.owners}
          filterKey={FilterKeys.Owner}
          filterValue={currentFilters[FilterKeys.Owner]}
          placeholder="Owner"
          onChange={updateFilters}
        />
      </Box>
      <Box ml={'auto'} sx={{ position: 'relative' }}>
        <FilterTextField placeholder="PR ID" onChange={searchByPRID} />
      </Box>
    </Box>
  )
}
