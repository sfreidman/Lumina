import { Button as BaseButton } from '@mui/base/Button'
import { Box, styled } from '@mui/material'
import React from 'react'
import { additionalPalette } from '../theme/theme'

interface FancySummaryButtonProps {
  id: string | number
  summary: string | number
  label: string
  color: string
  isSelected: boolean
  select: (id: string | number, isSelected: boolean) => void
}

const notSelectedBoxShadow =
  '0px 2px 4px -1px rgba(0,0,0,0.2), 0px 4px 5px 0px rgba(0,0,0,0.14), 0px 1px 10px 0px rgba(0,0,0,0.12)'
const selectedBoxShadow =
  'inset 2px 1px 6px 0px rgba(0,0,0,0.2), inset 0px 2px 5px 0px rgba(0,0,0,0.14), inset 0px 1px 4px 0px rgba(0,0,0,0.12)'

const Button = styled(BaseButton)<{ $isSelected: boolean; $color: string }>(({ $isSelected, $color }) => ({
  cursor: 'pointer',
  boxShadow: $isSelected ? selectedBoxShadow : notSelectedBoxShadow,
  border: 'none',
  borderLeft: `5px solid ${$color}`,
  padding: '10px',
  width: 100,
  textAlign: 'center',
  borderRadius: '8px',
  backgroundColor: additionalPalette.white,
}))

export const FancySummaryButton = React.memo(
  ({ id, summary, label, color, isSelected, select }: FancySummaryButtonProps) => {
    return (
      <Button onClick={() => select(id, !isSelected)} $isSelected={isSelected} $color={color}>
        <Box color={color} fontSize={20} mb={0.5} fontWeight={500}>
          {summary}
        </Box>
        <Box fontSize={14} color={additionalPalette.fancySummaryButtonColor}>
          {label}
        </Box>
      </Button>
    )
  },
)

FancySummaryButton.displayName = 'FancySummaryButton'
