import styled from '@emotion/styled'
import { Box } from '@mui/material'

export const BoxTextOverflow = styled(Box)({
  textWrap: 'nowrap',
  overflow: 'hidden',
  textOverflow: 'ellipsis',
})
