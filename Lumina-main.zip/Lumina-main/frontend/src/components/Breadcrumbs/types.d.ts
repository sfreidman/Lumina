export type Breadcrumb = {
  title: string
  path: string
  params: Record<string, string>
}
