import { NavigateNext as NavigateNextIcon } from '@mui/icons-material'
import { Breadcrumbs as MuiBreadcrumbs, Link as MuiLink, Typography } from '@mui/material'
import { Link } from '@tanstack/react-router'
import { Breadcrumb } from './types'

interface BreadcrumbsProps {
  crumbs: Breadcrumb[]
}

export function Breadcrumbs({ crumbs }: BreadcrumbsProps) {
  return (
    <MuiBreadcrumbs
      sx={{
        position: 'fixed',
        top: 48,
        background: (theme) => theme.palette.background.default,
        width: '100%',
        maxWidth: 'inherit',
        py: 0.5,
        paddingLeft: 3,
        zIndex: 999,
        borderBottom: (theme) => `1px solid ${theme.palette.divider}`,
      }}
      separator={<NavigateNextIcon fontSize="small" />}
      aria-label="breadcrumb"
    >
      {crumbs.map((breadcrumb, index) => {
        if (index === crumbs.length - 1) {
          return (
            <Typography key={breadcrumb.path} variant="subtitle1" sx={{ fontSize: 16 }}>
              {breadcrumb.title}
            </Typography>
          )
        }
        return (
          <Link
            style={{ textDecoration: 'none' }}
            key={breadcrumb.path}
            to={breadcrumb.path}
            params={breadcrumb.params}
          >
            <MuiLink underline="hover">
              <Typography variant="subtitle1" sx={{ fontSize: 16 }}>
                {breadcrumb.title}
              </Typography>
            </MuiLink>
          </Link>
        )
      })}
    </MuiBreadcrumbs>
  )
}
