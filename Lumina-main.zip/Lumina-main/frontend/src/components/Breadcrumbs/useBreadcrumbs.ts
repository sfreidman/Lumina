import { useRouter } from '@tanstack/react-router'
import { useMemo } from 'react'
import { Breadcrumb } from './types'

export const useBreadcrumbs = (): Breadcrumb[] => {
  const router = useRouter()
  const breadcrumbs = useMemo(() => {
    const b = router.state.matches
      .map((match, index) => {
        const { routeContext } = match
        if (!('getTitle' in routeContext)) {
          if (index === 0 && import.meta.env.DEV) {
            console.warn('no getTitle', match.pathname, match)
          }

          return {
            title: '',
            path: match.pathname,
            params: match.params,
          }
        }

        return {
          title: routeContext.getTitle(),
          path: 'getPath' in routeContext ? routeContext.getPath() : match.pathname,
          params: match.params,
        }
      })
      .filter((x) => x.path !== '/')

    b.unshift({
      title: 'Home',
      path: '/',
      params: {},
    })
    return b
  }, [router.state.matches])

  return breadcrumbs
}
