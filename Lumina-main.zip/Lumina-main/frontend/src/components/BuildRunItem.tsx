import CheckCircleIcon from '@mui/icons-material/CheckCircle'
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline'
import { Box, Checkbox, Theme, Tooltip } from '@mui/material'
import { useCallback, useMemo } from 'react'
import TimeAgo from 'react-timeago'
import { BuildRunUI, RelatedBuildUI } from '../api/models/build-runs'
import { SelectedJenkinsRuns } from '../routes/_layout/pull-requests/$prId/_pr-layout/jenkins-runs/$buildSha/$buildId/_jenkins-runs-layout'
import { additionalPalette } from '../theme/theme'
import { BoxTextOverflow } from './BoxTextOverfolw'
import { RelatedBuildItem } from './RelatedBuildItem'

interface BuildRunItemProps {
  buildRun: BuildRunUI
  selected: boolean
  maxWidth: string
  maxHeight?: string
  selectedBuildRuns: SelectedJenkinsRuns | null
  onSelect(selectedJenkinsRuns: SelectedJenkinsRuns): void
}

const shaDisplayLength = 7
const checkIconWidth = '20px'

export const BuildRunItem = ({ buildRun, maxWidth, maxHeight, selectedBuildRuns, onSelect }: BuildRunItemProps) => {
  const isAllSelected = useMemo(
    () => selectedBuildRuns?.buildRun?.sha === buildRun.sha && selectedBuildRuns.allSelected,
    [selectedBuildRuns, buildRun.sha],
  )
  const shaSliced = useMemo(() => buildRun.sha.substring(0, shaDisplayLength), [buildRun.sha])
  const hasRelatedBuild = useMemo(() => buildRun.related_builds.length > 0, [buildRun.related_builds])
  const selectRelatedBuild = useCallback(
    (relatedBuild: RelatedBuildUI) => {
      onSelect({
        buildRun,
        relatedBuild,
        allSelected: false,
        relatedBuildsCount: buildRun.related_builds.length,
      })
    },
    [buildRun, onSelect],
  )

  const selectAllRelatedBuilds = useCallback(
    (checked: boolean) => {
      let newSelectedState = null
      if (checked) {
        newSelectedState = {
          buildRun,
          relatedBuild: undefined,
          allSelected: true,
          relatedBuildsCount: buildRun.related_builds.length,
        }
      } else {
        newSelectedState = {
          buildRun,
          relatedBuild: buildRun.related_builds[0],
          allSelected: false,
          relatedBuildsCount: 1,
        }
      }
      onSelect(newSelectedState)
    },
    [buildRun, onSelect],
  )

  return (
    <Box
      borderRadius={2}
      border={(theme: Theme) => {
        return selectedBuildRuns?.buildRun?.sha === buildRun.sha
          ? `1px solid ${theme.palette.secondary.main}`
          : '1px solid transparent'
      }}
      bgcolor={additionalPalette.buildRunItemBgColor}
      p={1}
      maxWidth={maxWidth}
      maxHeight={maxHeight}
      position={'relative'}
      overflow={'visible'}
    >
      <Box>
        <Tooltip title={buildRun.message}>
          <BoxTextOverflow width={`calc(100% - ${checkIconWidth})`}>{buildRun.message}</BoxTextOverflow>
        </Tooltip>
        <BoxTextOverflow mb={2} fontSize={12} color={additionalPalette.buildRunItemSubTitleColor}>
          {shaSliced} | commited &nbsp;
          <TimeAgo date={buildRun.submitted_time} />
        </BoxTextOverflow>
      </Box>
      {hasRelatedBuild ? (
        buildRun.related_builds.map((relatedBuild) => (
          <RelatedBuildItem
            key={relatedBuild.build_run_id}
            build={relatedBuild}
            disabled={isAllSelected}
            selected={isAllSelected || selectedBuildRuns?.relatedBuild?.build_run_id === relatedBuild.build_run_id}
            onSelect={() => selectRelatedBuild(relatedBuild)}
            maxHeight={28}
          />
        ))
      ) : (
        <Box
          display={'flex'}
          alignItems={'center'}
          bgcolor={additionalPalette.buildRunItemNotValidatedBgColor}
          height={28}
          borderRadius={2.3}
          px={1.5}
        >
          <Box
            bgcolor={'transparent'}
            border={`1px solid ${additionalPalette.buildRunItemNotValidatedBorderColor}`}
            height={15}
            width={15}
            borderRadius={'50%'}
            mr={2}
          ></Box>
          <Box>Not validated</Box>
        </Box>
      )}
      {hasRelatedBuild && buildRun.related_builds.length > 1 && (
        <Checkbox
          sx={{ position: 'absolute', top: 1 - 6, right: -6 }}
          icon={<CheckCircleOutlineIcon sx={{ width: checkIconWidth, height: checkIconWidth }} />}
          checkedIcon={<CheckCircleIcon sx={{ width: checkIconWidth, height: checkIconWidth }} />}
          checked={isAllSelected}
          onChange={(_e, checked) => selectAllRelatedBuilds(checked)}
        />
      )}
    </Box>
  )
}
