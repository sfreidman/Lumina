import { Divider, Stack } from '@mui/material'
import Box from '@mui/material/Box'
import { useMemo } from 'react'
import { OutageStatus, OutageUI } from '../api/models/outage'
import AlertIcon from '../assets/icons/alert-icon.svg?react'
import { Severity } from '../enums/severity'
import { StringMap } from '../models/string-map'
import theme from '../theme/theme'
import { Collapse } from './Collapse'
import { OutageMessageBody } from './OutageMessageBody'
import { VerticalLineSeparator } from './VerticalLineSeparator'

interface OutageMessageProps {
  message: OutageUI
  isOpen?: boolean
}

const getSeverity = (status: OutageStatus) => {
  switch (status) {
    case OutageStatus.IN_PROGRESS:
      return Severity.DANGER
    case OutageStatus.SCHEDULED:
      return Severity.WARNING
    default:
      return Severity.INFO
  }
}

const mapOutageKeyToField = (key: string) => {
  switch (key) {
    case 'message_text':
      return 'Description'
    case 'impact':
      return 'Impact'
    case 'ar':
      return 'AR'
    case 'root_cause':
      return 'Root Cause'
    case 'solution':
      return 'Solution'
    default:
      return key
  }
}

const messageBodyKeys = {
  message_text: 'message_text',
  impact: 'impact',
  ar: 'ar',
  root_cause: 'root_cause',
  solution: 'solution',
}

const separatorColor = theme.palette.grey[900]

export const OutageMessage = ({ message, isOpen }: OutageMessageProps) => {
  /**
   * Populates the message body with the message keys and values
   * It is used to print only the relevant keys and values and exclude those that are belong to the header (title, start_time, end_time, status, etc...)
   */
  const messageBody = useMemo(() => {
    const body: StringMap = {}
    Object.keys(messageBodyKeys).forEach((key) => {
      const outageKey = key as keyof OutageUI
      if (key && message[outageKey] && messageBodyKeys[key as keyof typeof messageBodyKeys]) {
        body[key.toString()] = message[outageKey]?.toString() ?? ''
      }
    })
    return body
  }, [message])

  const formatDate = (date: Date) => `${date.toLocaleDateString()} ${date.toLocaleTimeString()}`

  return (
    <Collapse severity={getSeverity(message.status)} isOpen={isOpen}>
      <Box display="flex" flexDirection="row" alignItems="center">
        <AlertIcon height={30} width={30} />
        <Box ml={2} display={'flex'} alignItems={'center'}>
          {message.status === OutageStatus.IN_PROGRESS ? 'Active Outage' : 'Upcoming Outage'}
          <VerticalLineSeparator height="18px" bgColor={separatorColor} />
          {message.title} <VerticalLineSeparator height="18px" bgColor={separatorColor} />
          {message.start_time && <Box component={'span'}>From: {formatDate(message.start_time)}</Box>}&nbsp;
          {message.end_time && <Box component={'span'}>To: {formatDate(message.end_time)}</Box>}
        </Box>
      </Box>
      <Stack direction="column" divider={<Divider />} spacing={0.5}>
        {Object.keys(messageBody)
          .filter((key) => !!message[key as keyof OutageUI])
          .map((key) => (
            <Box key={key}>
              <OutageMessageBody
                label={mapOutageKeyToField(key)}
                content={message[key as keyof OutageUI]!.toString()}
              />
            </Box>
          ))}
      </Stack>
    </Collapse>
  )
}
