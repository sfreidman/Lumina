import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos'
import Box from '@mui/material/Box'
import { useMemo, useState } from 'react'
import { Severity } from '../enums/severity'
import { additionalPalette as palette } from '../theme/theme'

interface CollapseProps {
  severity: Severity
  children: React.ReactNode[]
  isOpen?: boolean
}

export const Collapse = ({ severity, children, isOpen = false }: CollapseProps) => {
  const [open, setOpen] = useState(isOpen)
  const headerColor = useMemo(
    () => palette?.[severity.toLocaleLowerCase() as 'info' | 'warning' | 'danger'].main,
    [severity],
  )
  const bodyColor = useMemo(
    () => palette?.[severity.toLocaleLowerCase() as 'info' | 'warning' | 'danger'].secondary,
    [severity],
  )

  const toggle = () => {
    setOpen(!open)
  }

  return (
    <Box>
      <Box
        onClick={toggle}
        display={'flex'}
        flexDirection={'row'}
        alignItems={'center'}
        bgcolor={headerColor}
        px={2}
        py={1}
        borderRadius={'5px'}
        sx={{ cursor: 'pointer' }}
      >
        {children && children[0]}
        <ArrowForwardIosIcon
          sx={{ marginLeft: 'auto', transform: open ? 'rotate(90deg)' : 'none', transition: 'all 250ms ease-out' }}
        />
      </Box>
      {children[1] && (
        <Box
          bgcolor={bodyColor}
          border={`${open ? '1px solid' + headerColor : 'none'}`}
          py={`${open ? '10px' : 0}`}
          px={8}
          borderRadius={'5px'}
          overflow={'hidden'}
          height={open ? 'auto' : 0}
          sx={{}}
        >
          {children[1]}
        </Box>
      )}
    </Box>
  )
}
