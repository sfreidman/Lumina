import { Box } from '@mui/material'

interface OutageMessageBodyProps {
  label: string
  content: string
}

export const OutageMessageBody = ({ label, content }: OutageMessageBodyProps) => {
  return (
    <Box mt={3} mb={2.5} display="flex">
      <Box mr={3.5} sx={{ minWidth: '100px' }}>
        {label}:
      </Box>
      <Box component="span">{content}</Box>
    </Box>
  )
}
