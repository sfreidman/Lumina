import { TipsAndUpdates as TipsAndUpdatesIcon } from '@mui/icons-material'
import { Alert, Box, Button, Grid, Paper, Typography } from '@mui/material'
import { createFileRoute, useNavigate } from '@tanstack/react-router'
import { ErrorResponse } from 'oidc-client-ts'
import { useEffect, useState } from 'react'
import { useAuth } from 'react-oidc-context'
import { saveLocationAndRedirectToLogin } from '../utils'

export const Route = createFileRoute('/login')({
  component: Login,
})

function Login() {
  const auth = useAuth()
  const [errorMessage, setErrorMessage] = useState<string | undefined>()
  const navigate = useNavigate()

  useEffect(() => {
    if (!auth.isLoading && auth.isAuthenticated) {
      navigate({ to: '/' })
    }
  }, [auth.isAuthenticated, auth.isLoading, navigate])

  useEffect(() => {
    if (!auth.error) {
      setErrorMessage(undefined)
      return
    }

    // oauth provider needs some form of end-user interaction,
    // due to not being logged in, or similar reasons
    // => not a real error => ignore error so user can proceed to click "login" manually
    if (
      auth.error instanceof ErrorResponse &&
      ['interaction_required', 'login_required', 'account_selection_required', 'consent_required'].includes(
        auth.error.error || '',
      )
    ) {
      setErrorMessage(undefined)
      return
    }

    setErrorMessage(auth.error.message)
  }, [auth.error])

  const login = () => {
    saveLocationAndRedirectToLogin(auth)
  }

  return (
    <Grid
      container
      spacing={0}
      direction="column"
      alignItems="center"
      justifyContent="center"
      sx={{ minHeight: '100vh' }}
    >
      <Grid item xs={3}>
        <Paper sx={{ px: 4, py: 3 }}>
          <Box display="flex" alignItems="center" justifyContent="center">
            <TipsAndUpdatesIcon sx={{ mr: 1 }} />
            <Typography
              variant="h6"
              noWrap
              sx={{
                fontFamily: 'monospace',
                fontWeight: 700,
                letterSpacing: '.3rem',
              }}
            >
              LUMINA
            </Typography>
          </Box>
          <Box display="flex" justifyContent="center" mt={1}>
            <Typography noWrap>Please login in to continue</Typography>
          </Box>
          <Box mt={3} textAlign="center">
            <Button variant="contained" onClick={login} disabled={auth.isLoading}>
              Login
            </Button>
          </Box>
          {errorMessage && (
            <Box mt={3} mx={-1}>
              <Alert variant="outlined" severity="error">
                {errorMessage}
              </Alert>
            </Box>
          )}
        </Paper>
      </Grid>
    </Grid>
  )
}
