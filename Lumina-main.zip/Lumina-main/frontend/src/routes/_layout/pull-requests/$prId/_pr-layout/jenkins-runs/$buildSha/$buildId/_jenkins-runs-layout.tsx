import NotificationsActiveIcon from '@mui/icons-material/NotificationsActive'
import { Box, Drawer, Tabs, Typography } from '@mui/material'
import { Outlet, RouterState, createFileRoute, useNavigate, useRouterState } from '@tanstack/react-router'
import { useCallback, useEffect, useMemo, useState } from 'react'
import { BuildRunUI, RelatedBuildUI } from '../../../../../../../../api/models/build-runs'
import { OutageState } from '../../../../../../../../api/models/outage'
import { BuildRunItem } from '../../../../../../../../components/BuildRunItem'
import { SecondryNotCapitalizedTab } from '../../../../../../../../components/NotCapitalizedTab'
import { OutageMessage } from '../../../../../../../../components/OutageMessage'
import { useOutagesQuery, usePRRunsQuery } from '../../../../../../../../state/queries'
import { additionalPalette } from '../../../../../../../../theme/theme'

export const Route = createFileRoute(
  '/_layout/pull-requests/$prId/_pr-layout/jenkins-runs/$buildSha/$buildId/_jenkins-runs-layout',
)({
  beforeLoad: () => ({ getTitle: () => 'Jenkins Runs' }),
  component: JenkinsRuns,
})

export interface SelectedJenkinsRuns {
  buildRun?: BuildRunUI
  relatedBuild?: RelatedBuildUI
  relatedBuildsCount?: number
  allSelected: boolean
}

const shaDisplayLength = 7

const getTabByRouterState = (routerState: RouterState) => {
  const path = routerState.matches[routerState.matches.length - 1]
  const pathParts = path.pathname.split('/')
  const tab = pathParts[pathParts.length - 1]
  switch (tab) {
    case 'stages-run-summary':
      return 0
    case 'comparison':
      return 1
    default:
      return 0
  }
}

function JenkinsRuns() {
  const [init, setInt] = useState(false) // TODO: fix hack
  const { prId, buildSha, buildId } = Route.useParams()
  const navigate = useNavigate()
  const routerState = useRouterState()
  const { data: prRuns } = usePRRunsQuery(prId)
  const { data: outages } = useOutagesQuery(OutageState.RELEVANT, prId, buildId)
  const [drawerOpen, setDrawerOpen] = useState(false)

  const [selectedJenkinsRuns, setSelectedJenkinsRuns] = useState<SelectedJenkinsRuns>({
    buildRun: undefined,
    relatedBuild: undefined,
    allSelected: false,
    relatedBuildsCount: undefined,
  })

  const shaSliced = useMemo(
    () => selectedJenkinsRuns?.buildRun?.sha.substring(0, shaDisplayLength),
    [selectedJenkinsRuns?.buildRun],
  )

  const selectedRunTitle = useMemo(() => {
    let buildRunText = undefined
    if (selectedJenkinsRuns.buildRun || selectedJenkinsRuns.relatedBuild || selectedJenkinsRuns.allSelected) {
      buildRunText = `${selectedJenkinsRuns.buildRun?.message} | ${shaSliced}`
      if (!selectedJenkinsRuns.allSelected) {
        buildRunText = `#${selectedJenkinsRuns.relatedBuild?.build_run_id} ${buildRunText}`
      }
    }
    return buildRunText
  }, [selectedJenkinsRuns, shaSliced])

  // get last part of the url
  const tab = getTabByRouterState(routerState)

  const switchTab = useCallback(
    (_event: React.SyntheticEvent, newTab: number) => {
      const params = { prId, buildSha, buildId }
      switch (newTab) {
        case 0:
          navigate({ to: `/pull-requests/$prId/jenkins-runs/$buildSha/$buildId/stages-run-summary`, params })
          break
        case 1:
          navigate({ to: `/pull-requests/$prId/jenkins-runs/$buildSha/$buildId/comparison`, params })
          break
      }
    },
    [buildId, buildSha, navigate, prId],
  )

  useEffect(() => {
    if (!prRuns) return
    setInt(true)
    const commitSelected = prRuns?.find((run) => run.sha.substring(0, shaDisplayLength) === buildSha)
    const isAllSelected = buildId === 'all'
    const relatedBuild = isAllSelected
      ? undefined
      : commitSelected?.related_builds.find((build) => build.build_run_id === Number(buildId))
    const relatedBuildsCount = isAllSelected ? commitSelected?.related_builds.length : undefined
    setSelectedJenkinsRuns({
      buildRun: commitSelected,
      relatedBuild,
      allSelected: isAllSelected,
      relatedBuildsCount,
    })
  }, [prRuns, buildSha, buildId])

  useEffect(() => {
    if (init) {
      // TODO: Fix this workaround
      navigate({
        to: `/pull-requests/$prId/jenkins-runs/$buildSha/$buildId/stages-run-summary`,
        params: {
          prId,
          buildSha: selectedJenkinsRuns?.buildRun?.sha.substring(0, shaDisplayLength) || 'none',
          buildId: selectedJenkinsRuns?.allSelected
            ? 'all'
            : selectedJenkinsRuns?.relatedBuild?.build_run_id.toString() || 'none',
        },
      })
    }
  }, [selectedJenkinsRuns, navigate, prId, init])

  return (
    <Box display={'flex'}>
      <Box width={'20%'} maxWidth={250} mr={2}>
        <Typography variant="h5" mb={3} fontSize={20} fontWeight={500} color={additionalPalette.jenkinsRunTitleColor}>
          Jenkins runs
        </Typography>
        <Box>
          <Box overflow={'auto'} pr={2}>
            {prRuns?.map((buildRun) => (
              <Box mb={1} key={buildRun.sha}>
                <BuildRunItem
                  buildRun={buildRun}
                  selected={false}
                  maxWidth="100%"
                  selectedBuildRuns={selectedJenkinsRuns}
                  onSelect={setSelectedJenkinsRuns}
                />
              </Box>
            ))}
          </Box>
        </Box>
      </Box>
      <Box width={'100%'}>
        <Box>
          <Typography
            variant="h5"
            mb={3}
            fontSize={20}
            fontWeight={500}
            color={additionalPalette.jenkinsRunSelectedRunTitleColor}
          >
            {selectedRunTitle}
          </Typography>
        </Box>
        <Box display={'flex'} alignItems={'center'} flexDirection={'row'} pr={2}>
          <Tabs value={tab} onChange={switchTab} role="navigation">
            <SecondryNotCapitalizedTab $selected={tab === 0} label="Stages runs summary" />
            <SecondryNotCapitalizedTab $selected={tab === 1} label="Comparison" />
          </Tabs>
          {outages && outages?.length > 0 && (
            <Box
              ml={'auto'}
              position={'relative'}
              sx={{
                cursor: 'pointer', // Changes the cursor to a pointer on hover
              }}
              onClick={() => setDrawerOpen(true)}
            >
              <NotificationsActiveIcon />
              <Box
                width={14}
                height={14}
                position={'absolute'}
                top={-8}
                right={-3}
                bgcolor={additionalPalette.errorNotificationBgColor}
                color={additionalPalette.errorNotificationColor}
                borderRadius={'50%'}
                p={0.1}
                fontSize={10}
                textAlign={'center'}
              >
                {outages.length}
              </Box>
            </Box>
          )}
        </Box>
        {/* TODO Sveta: Will add coloring bgcolor={'green'} */}
        <Box mt={3}>
          <Outlet />
        </Box>
      </Box>
      <Drawer
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        anchor={'right'}
        sx={{
          zIndex: 1201,
          '& .MuiDrawer-paper': {
            width: '50%',
            bgcolor: additionalPalette.stageDetailsDrawerBgColor,
            boxShadow: additionalPalette.defaultBoxShadow,
          },
        }}
      >
        <Box mt={2}>
          {outages?.map((outage) => (
            <Box key={outage.id} mb={2}>
              <OutageMessage message={outage} isOpen={true} />
            </Box>
          ))}
        </Box>
      </Drawer>
    </Box>
  )
}
