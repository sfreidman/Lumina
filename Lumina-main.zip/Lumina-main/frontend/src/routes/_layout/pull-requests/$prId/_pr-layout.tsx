import { Search } from '@mui/icons-material'
import { Box, InputAdornment, Skeleton, Tabs, TextField, debounce } from '@mui/material'
import { Outlet, createFileRoute, useNavigate, useRouterState } from '@tanstack/react-router'
import { useCallback, useMemo } from 'react'
import { PROwnerRole } from '../../../../api/models/pull-request'
import { ColorIndicatorLabel } from '../../../../components/ColorIndicatorLabel'
import { NotCapitalizedTab } from '../../../../components/NotCapitalizedTab'
import { PRTableLabelCell } from '../../../../components/PRListTable/PRTableLabelCell'
import { usePRDetailsQuery, usePRRunsQuery } from '../../../../state/queries'
import { colorIndicators } from '../../../../theme/color-indicators'
import { additionalPalette } from '../../../../theme/theme'

export const Route = createFileRoute('/_layout/pull-requests/$prId/_pr-layout')({
  beforeLoad: ({ params: { prId } }) => ({ getTitle: () => prId }),
  component: PullRequestDetails,
})

function PullRequestDetails() {
  const { prId } = Route.useParams()
  const { data: prRuns } = usePRRunsQuery(prId)
  const navigate = useNavigate()
  const routerState = useRouterState()
  const { data: prDetails, isLoading: prDetailsLoading } = usePRDetailsQuery(prId)

  // get last part of the url
  const tab = useMemo(() => {
    const path = routerState.matches[routerState.matches.length - 1]
    const pathParts = path.pathname.split('/')
    const tab = pathParts[pathParts.length - 1]
    switch (tab) {
      case 'jenkins-runs':
        return 0
      case 'new-jenkins-run':
        return 1
      case 'merge-pull-request':
        return 2
      default:
        return 0
    }
  }, [routerState.matches])

  const owner = useMemo(() => {
    return prDetails?.pr_owners.find((owner) => owner.role === PROwnerRole.AUTHOR)
  }, [prDetails])

  const searchByPRID = useMemo(
    () => (id: string) => {
      if (id !== '') {
        console.log('search by pr id', id)
      }
    },
    [],
  )

  const latestRunWithRelatedRuns = useMemo(() => {
    return prRuns?.filter((run) => run.related_builds.length > 0)[0]
  }, [prRuns])

  const switchTab = useCallback(
    (_event: React.SyntheticEvent, newTab: number) => {
      const params = { prId }
      switch (newTab) {
        case 0:
          navigate({
            to: `/pull-requests/$prId/jenkins-runs/$buildSha/$buildId/stages-run-summary`,
            params: {
              prId,
              buildSha: latestRunWithRelatedRuns?.sha.substring(0, 7) || 'none',
              buildId: latestRunWithRelatedRuns?.related_builds[0].build_run_id.toString() || 'none',
            },
          })
          break
        case 1:
          navigate({ to: `/pull-requests/$prId/new-jenkins-run`, params })
          break
        case 2:
          navigate({ to: `/pull-requests/$prId/merge-pull-request`, params })
          break
      }
    },
    [prId, latestRunWithRelatedRuns],
  )

  return (
    <>
      <Box mx={-3}>
        {prDetailsLoading ? (
          <Box>
            <Box bgcolor={additionalPalette.prDetailsTitleBgColor} p={3} height={'120px'}>
              <Skeleton animation="wave" variant="rectangular" width={'50%'} height={40} sx={{ mb: 2 }} />
              <Box display={'flex'}>
                <Skeleton animation="wave" variant="rectangular" width={'15%'} height={15} sx={{ mr: 1 }} />
                <Skeleton animation="wave" variant="rectangular" width={'15%'} height={15} sx={{ mr: 1 }} />
                <Skeleton animation="wave" variant="rectangular" width={'15%'} height={15} />
              </Box>
            </Box>
            <Box
              display={'flex'}
              alignItems={'center'}
              px={3}
              bgcolor={additionalPalette.prDetailsSubTitleBgColor}
              height={50}
            >
              <Skeleton animation="wave" variant="rectangular" width={'20%'} height={35} sx={{ mr: 1 }} />
              <Skeleton animation="wave" variant="rectangular" width={'20%'} height={35} sx={{ mr: 1 }} />
              <Skeleton animation="wave" variant="rectangular" width={'20%'} height={35} />
            </Box>
          </Box>
        ) : (
          <Box>
            <Box bgcolor={additionalPalette.prDetailsTitleBgColor} p={3}>
              <Box display={'flex'} alignItems={'center'} mb={2}>
                <Box color={additionalPalette.prDetailsTitleColor} fontSize={25}>
                  {prDetails?.title} | {prDetails?.id}
                </Box>
                <Box ml={'auto'}>
                  <TextField
                    placeholder="PR ID"
                    variant="standard"
                    disabled={prDetailsLoading || true} // currently disabled
                    sx={{
                      width: 150,
                      '& .MuiOutlinedInput-notchedOutline': {
                        borderColor: additionalPalette.textFieldInputBorderColor,
                      },
                      '& .MuiOutlinedInput-root': { borderRadius: '5px' },
                      '& .MuiOutlinedInput-input': { paddingY: '4px' },
                    }}
                    InputProps={{
                      type: 'number',
                      startAdornment: (
                        <InputAdornment position="start">
                          <Search />
                        </InputAdornment>
                      ),
                    }}
                    onChange={debounce((e) => {
                      searchByPRID(e.target.value)
                    }, 500)}
                  />
                </Box>
              </Box>
              <Box display={'flex'} alignItems={'center'}>
                <Box color={additionalPalette.prDetailsSubTitleColor} mr={3}>
                  created by{' '}
                  <Box component={'span'} color={additionalPalette.prDetailsSubTitleEmphasizeColor}>
                    {owner?.user_name}
                  </Box>{' '}
                  | from&nbsp;
                  <Box component={'span'} color={additionalPalette.prDetailsSubTitleEmphasizeColor}>
                    {prDetails?.branch_name}
                  </Box>{' '}
                  to&nbsp;
                  <Box component={'span'} color={additionalPalette.prDetailsSubTitleEmphasizeColor}>
                    {prDetails?.target_branch}
                  </Box>
                </Box>
                <PRTableLabelCell labels={prDetails?.pr_labels ?? []} maxLabelsDisplay={3} maxLabelWidth={'120px'} />
                {prDetails && prDetails.github_status && (
                  <Box display={'inline-block'} ml={'auto'}>
                    <ColorIndicatorLabel
                      label={'Github'}
                      color={colorIndicators[prDetails?.github_status]}
                      onClick={() => window.open(prDetails.github_link, '_blank')}
                    />
                  </Box>
                )}
              </Box>
            </Box>
            <Box bgcolor={additionalPalette.prDetailsSubTitleBgColor} px={3} mb={3}>
              <Tabs value={tab} onChange={switchTab} role="navigation" indicatorColor="secondary">
                <NotCapitalizedTab label="Jenkins runs summary" />
                <NotCapitalizedTab label="Start new Jenkins run" />
                <NotCapitalizedTab label="Merge pull request" />
              </Tabs>
            </Box>
          </Box>
        )}
      </Box>

      <Box>
        <Outlet />
      </Box>
    </>
  )
}
