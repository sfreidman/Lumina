import { Box } from '@mui/material'
import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { StagesListTable } from '../../../../../../../../../components/StagesListTable'
import { StagesTableFilters } from '../../../../../../../../../components/StagesListTable/StagesTableFilters'
import { usePRRunsStagesQuery } from '../../../../../../../../../state/queries'
import { additionalPalette } from '../../../../../../../../../theme/theme'

export const Route = createFileRoute(
  '/_layout/pull-requests/$prId/_pr-layout/jenkins-runs/$buildSha/$buildId/_jenkins-runs-layout/stages-run-summary',
)({
  beforeLoad: () => ({ getTitle: () => 'Stages Run Summary' }),
  component: StagesRunSummary,
})

function StagesRunSummary() {
  const { prId, buildId, buildSha } = Route.useParams()
  const {
    data: stages,
    isLoading,
    isError,
  } = usePRRunsStagesQuery(
    prId,
    buildId === 'all' ? 'pr-commits' : 'pr-runs',
    buildId === 'all' ? buildSha : undefined,
    Number(buildId),
  )
  const [stagesFiltered, setStagesFiltered] = useState(stages || [])

  return (
    <Box maxHeight={'100%'}>
      <Box mb={2}>
        Jenkins run status :
        <Box component={'span'} ml={1.5} color={additionalPalette.stagesRunSummaryRunStatusColor}>
          {'Running'}
        </Box>
      </Box>

      <Box mb={1.5}>{stages && <StagesTableFilters stages={stages} onStagesFiltered={setStagesFiltered} />}</Box>
      <StagesListTable stages={stagesFiltered || []} isLoading={isLoading} isError={isError} />
    </Box>
  )
}
