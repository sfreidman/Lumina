import { createFileRoute } from '@tanstack/react-router'

export const Route = createFileRoute('/_layout/pull-requests/$prId/_pr-layout/merge-pull-request')({
  beforeLoad: () => ({ getTitle: () => 'Merge Pull Request' }),
  component: MergePullRequest,
})

function MergePullRequest() {
  return <div>Merge Pull Request</div>
}
