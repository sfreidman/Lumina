import { createFileRoute } from '@tanstack/react-router'

export const Route = createFileRoute('/_layout/pull-requests/$prId/_pr-layout/new-jenkins-run')({
  beforeLoad: () => ({ getTitle: () => 'New Jenkins Run' }),
  component: NewJenkinsRun,
})

function NewJenkinsRun() {
  return <div>New Jenkins Run</div>
}
