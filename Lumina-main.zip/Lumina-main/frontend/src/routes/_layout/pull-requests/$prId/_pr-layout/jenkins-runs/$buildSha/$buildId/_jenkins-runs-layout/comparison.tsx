import { createFileRoute } from '@tanstack/react-router'

export const Route = createFileRoute(
  '/_layout/pull-requests/$prId/_pr-layout/jenkins-runs/$buildSha/$buildId/_jenkins-runs-layout/comparison',
)({
  component: Comparison,
})

export function Comparison() {
  return <div>Comparison</div>
}
