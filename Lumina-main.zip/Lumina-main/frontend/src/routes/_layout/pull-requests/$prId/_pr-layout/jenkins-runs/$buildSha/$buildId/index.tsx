import { Navigate, createFileRoute } from '@tanstack/react-router'

// TODO: This is a workaround for a bug in the router
// https://github.com/TanStack/router/issues/1150
export const Route = createFileRoute('/_layout/pull-requests/$prId/_pr-layout/jenkins-runs/$buildSha/$buildId/')({
  component: Workaround,
})

function Workaround() {
  const { prId, buildSha, buildId } = Route.useParams()
  return (
    <Navigate
      to={`/pull-requests/$prId/jenkins-runs/$buildSha/$buildId/stages-run-summary`}
      params={{ prId, buildSha, buildId }}
    />
  )
}
