import { Box, Skeleton, Typography } from '@mui/material'
import { createFileRoute } from '@tanstack/react-router'
import { useAtomValue } from 'jotai'
import { MRT_PaginationState, MRT_SortingState } from 'material-react-table'
import { useMemo, useState } from 'react'
import { OutageState, OutageStatus } from '../../../api/models/outage'
import { PullRequestUI } from '../../../api/models/pull-request'
import { OutageMessage } from '../../../components/OutageMessage'
import { PRListTable } from '../../../components/PRListTable'
import { PRListTableFilters } from '../../../components/PRListTable/PRListTableFilters'
import { StringMap } from '../../../models/string-map'
import { prFiltersQueryAtom, useOutagesQuery, usePRListQuery } from '../../../state/queries'
import { additionalPalette } from '../../../theme/theme'

export const Route = createFileRoute('/_layout/pull-requests/')({
  beforeLoad: () => ({ getTitle: () => 'Pull Requests' }),
  component: PullRequests,
})

function PullRequests() {
  const [prTableFilters, setPrTableFilters] = useState<StringMap>({})
  const [prTableSorting, setPrTableSorting] = useState<MRT_SortingState>([])
  const [prTablePagination, setPrTablePagination] = useState<MRT_PaginationState>({
    pageIndex: 0,
    pageSize: 20,
  })

  const {
    data: paginationResponse,
    isLoading: isPRListLoading,
    isError,
  } = usePRListQuery(prTablePagination, prTableSorting, prTableFilters)
  const { data: outageDatas, isLoading: isOutagesLoading } = useOutagesQuery(OutageState.ACTIVE)
  const { data: prFilters, isLoading: isPRFiltersLoading } = useAtomValue(prFiltersQueryAtom)

  const prs = useMemo<PullRequestUI[]>(() => paginationResponse?.results ?? [], [paginationResponse])
  const totalPrs = useMemo<number>(() => paginationResponse?.count ?? 0, [paginationResponse])
  const openPrs = useMemo<number>(() => paginationResponse?.open_prs ?? 0, [paginationResponse])

  const outages = useMemo(() => {
    if (outageDatas && outageDatas.length > 0) {
      const inProgressOutages = outageDatas.filter((outage) => outage.status === OutageStatus.IN_PROGRESS)
      const scheduledOutages = outageDatas.filter((outage) => outage.status === OutageStatus.SCHEDULED)
      return [...inProgressOutages, ...scheduledOutages]
    }
    return []
  }, [outageDatas])

  return (
    <Box>
      <Box sx={{ mb: 4 }}>
        {!isOutagesLoading &&
          outages?.map((message) => (
            <Box key={message.id} sx={{ mb: 1 }}>
              <OutageMessage message={message} />
            </Box>
          ))}
        {isOutagesLoading && (
          <Box>
            <Skeleton animation="wave" variant="rectangular" width={'100%'} height={40} sx={{ mb: 1 }} />
            <Skeleton animation="wave" variant="rectangular" width={'100%'} height={40} />
          </Box>
        )}
      </Box>
      <Box>
        <Typography color={additionalPalette.prListTitleColor} fontSize={24} fontWeight={500}>
          PR List
        </Typography>
        <Box display={'flex'} mb={2} alignItems={'center'}>
          <Box mr={15} color={additionalPalette.prListOpenItemsLabelColor} alignSelf={'flex-end'}>
            Open ({openPrs})
          </Box>
          {isPRFiltersLoading && (
            <Box display={'flex'}>
              <Skeleton animation="wave" variant="rectangular" width={300} height={40} sx={{ mr: 1 }} />
              <Skeleton animation="wave" variant="rectangular" width={300} height={40} sx={{ mr: 1 }} />
              <Skeleton animation="wave" variant="rectangular" width={300} height={40} />
            </Box>
          )}
          {!isPRFiltersLoading && prFilters && (
            <PRListTableFilters
              filters={prFilters}
              currentFilters={prTableFilters}
              onFiltersChange={setPrTableFilters}
            />
          )}
        </Box>
        <PRListTable
          data={prs}
          totalCount={totalPrs}
          isLoading={isPRListLoading}
          isError={isError}
          sorting={prTableSorting}
          setSorting={setPrTableSorting}
          pagination={prTablePagination}
          setPagination={setPrTablePagination}
        />
      </Box>
    </Box>
  )
}
