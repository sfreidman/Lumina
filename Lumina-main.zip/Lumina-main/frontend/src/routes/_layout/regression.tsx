import { Box } from '@mui/material'
import { createFileRoute } from '@tanstack/react-router'

export const Route = createFileRoute('/_layout/regression')({
  beforeLoad: () => ({ getTitle: () => 'Regression' }),
  component: Regression,
})

function Regression() {
  return (
    <Box className="p-2">
      <h3>Regression</h3>
    </Box>
  )
}
