import { Navigate, createFileRoute } from '@tanstack/react-router'

export const Route = createFileRoute('/_layout/')({
  beforeLoad: () => ({ getTitle: () => 'Home' }),
  component: Home,
})

function Home() {
  return <Navigate to="/pull-requests" />
}
