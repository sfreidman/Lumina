import { Backdrop, CircularProgress } from '@mui/material'
import { QueryClient } from '@tanstack/react-query'
import { ReactQueryDevtools } from '@tanstack/react-query-devtools'
import { Outlet, createRootRouteWithContext, useNavigate } from '@tanstack/react-router'
import { TanStackRouterDevtools } from '@tanstack/router-devtools'
import { useSetAtom } from 'jotai'
import { useEffect, useState } from 'react'
import { hasAuthParams, useAuth } from 'react-oidc-context'
import { ToastContainer } from 'react-toastify'
import { accessTokenAtom } from '../state/atoms'
import { additionalPalette } from '../theme/theme'
import { saveLocationAndRedirectToLogin } from '../utils'

interface RootContext {
  getTitle?: () => string | Promise<string>
  getPath?: () => string | Promise<string>
  queryClient: QueryClient
}

export const Route = createRootRouteWithContext<RootContext>()({
  component: RootComponent,
  // TODO: Create a 404 page
  // notFoundComponent:
})

function RootComponent() {
  const auth = useAuth()
  const [loginAttempted, setLoginAttempted] = useState(false)
  const navigate = useNavigate()
  const setAccessToken = useSetAtom(accessTokenAtom)

  useEffect(() => {
    const tryLogin = async () => {
      if (auth.user?.refresh_token) {
        const res = await auth.signinSilent()
        if (!res) {
          saveLocationAndRedirectToLogin(auth)
        }
      } else {
        saveLocationAndRedirectToLogin(auth)
      }
    }

    if (
      !loginAttempted &&
      !hasAuthParams() &&
      !auth.isAuthenticated &&
      !auth.activeNavigator &&
      !auth.isLoading &&
      !auth.error
    ) {
      setLoginAttempted(true)
      tryLogin()
    }
  }, [auth, loginAttempted])

  useEffect(() => {
    if (!auth.isLoading && auth.error) {
      navigate({ to: '/login' })
    }
  }, [auth.error, auth.isLoading, navigate])

  useEffect(() => {
    if (auth.isLoading) {
      return
    }

    const accessToken = auth.isAuthenticated ? auth?.user?.access_token : null
    setAccessToken(accessToken)
  }, [auth.isAuthenticated, auth.isLoading, auth?.user, setAccessToken])

  return (
    <>
      <Backdrop
        sx={{ color: additionalPalette.rootBackdropColor, zIndex: (theme) => theme.zIndex.drawer + 1 }}
        open={auth.isLoading}
      >
        <CircularProgress color="inherit" />
      </Backdrop>
      <Outlet />
      <ToastContainer />
      <ReactQueryDevtools />
      <TanStackRouterDevtools />
    </>
  )
}
