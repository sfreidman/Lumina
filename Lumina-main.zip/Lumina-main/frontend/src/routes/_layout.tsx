import {
  AllInclusive as AllInclusiveIcon,
  BugReport as BugReportIcon,
  Home as HomeIcon,
  Percent as PercentIcon,
  TipsAndUpdates as TipsAndUpdatesIcon,
  TrendingUp as TrendingUpIcon,
} from '@mui/icons-material'
import KeyboardArrowLeftIcon from '@mui/icons-material/KeyboardArrowLeft'
import MenuIcon from '@mui/icons-material/Menu'
import {
  AppBar,
  Avatar,
  Box,
  Container,
  Divider,
  Drawer,
  IconButton,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Menu,
  MenuItem,
  Toolbar,
  Tooltip,
  Typography,
  styled,
  useMediaQuery,
} from '@mui/material'
import { Link, Outlet, createFileRoute, useRouterState } from '@tanstack/react-router'
import { useAtomValue } from 'jotai'
import { MouseEvent, forwardRef, useEffect, useState } from 'react'
import { useAuth } from 'react-oidc-context'
import PrIcon from '../assets/icons/git-pull-request-icon.svg?react'
import { Breadcrumbs } from '../components/Breadcrumbs/Breadcrumbs'
import { useBreadcrumbs } from '../components/Breadcrumbs/useBreadcrumbs'
import { userMeQueryAtom } from '../state/queries'
import theme, { additionalPalette } from '../theme/theme'

export const Route = createFileRoute('/_layout')({
  component: Layout,
})

const drawerOpenWidth = 200
const drawerClosedWidth = 53

const ListItemStyled = styled(ListItem)<{ $drawerOpen: boolean }>(({ $drawerOpen, theme }) => ({
  '&.Mui-selected': {
    borderLeft: `${$drawerOpen ? '7px' : '2px'} solid ${additionalPalette.leftDrawerListItemActiveLeftBorderColor}`,
    transition: 'all 0.1s linear',
    backgroundColor: theme.palette.background.paper,
    color: theme.palette.primary.main,

    '& .MuiListItemIcon-root': {
      color: theme.palette.primary.main,
    },
    '& .MuiTypography-root': {
      fontWeight: 500,
    },
  },
}))

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const LinkWrapper = forwardRef((props: any, ref) => {
  return <Link {...props} to={props.href} ref={ref} />
})

function Layout() {
  const { data } = useAtomValue(userMeQueryAtom)
  const [anchorElUser, setAnchorElUser] = useState<null | HTMLElement>(null)
  const routerState = useRouterState()
  const matches = useMediaQuery(theme.breakpoints.up('xl'))
  const [drawerOpen, setDrawerOpen] = useState(matches)

  const auth = useAuth()
  const breadcrumbs = useBreadcrumbs()

  const handleOpenUserMenu = (event: MouseEvent<HTMLElement>) => {
    setAnchorElUser(event.currentTarget)
  }

  const logout = () => {
    handleCloseUserMenu()
    auth.signoutRedirect()
  }

  const handleCloseUserMenu = () => {
    setAnchorElUser(null)
  }

  const toggleDrawer = () => {
    setDrawerOpen((open) => !open)
  }

  useEffect(() => {
    setDrawerOpen(matches)
  }, [matches])

  return (
    <Box sx={{ display: 'flex' }}>
      <AppBar position="fixed" sx={{ zIndex: (theme) => theme.zIndex.drawer + 1 }}>
        <Container maxWidth={false}>
          <Toolbar disableGutters variant="dense">
            <Link to="/" style={{ textDecoration: 'none', display: 'inline-flex', alignItems: 'center' }}>
              <TipsAndUpdatesIcon
                sx={{ display: 'flex', mr: 1, color: (theme) => theme.palette.primary.contrastText }}
              />
              <Typography
                variant="h6"
                noWrap
                sx={{
                  display: 'flex',
                  fontFamily: 'monospace',
                  fontWeight: 700,
                  letterSpacing: '.3rem',
                  color: (theme) => theme.palette.primary.contrastText,
                  textDecoration: 'none !important',
                }}
              >
                LUMINA
              </Typography>
            </Link>
            <Box sx={{ flexGrow: 1 }}></Box>
            <Box sx={{ flexGrow: 0 }}>
              <Tooltip title="Settings">
                <IconButton onClick={handleOpenUserMenu} sx={{ p: 0 }}>
                  <Avatar sx={{ width: 32, height: 32 }} />
                </IconButton>
              </Tooltip>
              <Menu
                sx={{ mt: '30px' }}
                id="menu-appbar"
                anchorEl={anchorElUser}
                anchorOrigin={{
                  vertical: 'top',
                  horizontal: 'right',
                }}
                keepMounted
                transformOrigin={{
                  vertical: 'top',
                  horizontal: 'right',
                }}
                open={Boolean(anchorElUser)}
                onClose={handleCloseUserMenu}
              >
                <Box px={2} py={1}>
                  <Typography
                    variant="body2"
                    color={(theme) => theme.palette.text.secondary}
                  >{`${data?.first_name} ${data?.last_name}`}</Typography>
                </Box>
                <MenuItem onClick={logout}>
                  <Typography>Logout</Typography>
                </MenuItem>
              </Menu>
            </Box>
          </Toolbar>
        </Container>
      </AppBar>
      <Drawer
        open={drawerOpen}
        sx={{
          width: drawerOpen ? drawerOpenWidth : drawerClosedWidth,
          flexShrink: 0,
          transition: 'all 0.2s linear',
          '& .MuiDrawer-paper': {
            transition: 'all 0.2s linear',
            width: drawerOpen ? drawerOpenWidth : drawerClosedWidth,
            boxSizing: 'border-box',
            top: '48px',
            textWrap: 'nowrap',
            backgroundColor: (theme) => theme.palette.primary.main,
            color: (theme) => theme.palette.primary.contrastText,
          },
        }}
        variant="permanent"
        anchor="left"
      >
        <List>
          <ListItem disablePadding>
            <ListItemButton onClick={toggleDrawer}>
              <ListItemIcon sx={{ minWidth: 36, color: (theme) => theme.palette.primary.contrastText }}>
                {drawerOpen ? <KeyboardArrowLeftIcon /> : <MenuIcon />}
              </ListItemIcon>
            </ListItemButton>
          </ListItem>
          {/* TODO: Hide the home page */}
          <ListItemStyled
            $drawerOpen={drawerOpen}
            disablePadding
            sx={{ display: 'none' }}
            selected={routerState.location.pathname === '/'}
          >
            <ListItemButton href="/" LinkComponent={LinkWrapper}>
              <ListItemIcon sx={{ minWidth: 36, color: (theme) => theme.palette.primary.contrastText }}>
                <HomeIcon />
              </ListItemIcon>
              <ListItemText primary="Home" />
            </ListItemButton>
          </ListItemStyled>
          <ListItemStyled
            disablePadding
            selected={routerState.location.pathname === '/pull-requests'}
            $drawerOpen={drawerOpen}
          >
            <ListItemButton href="pull-requests" LinkComponent={LinkWrapper}>
              <ListItemIcon sx={{ minWidth: 36, color: (theme) => theme.palette.primary.contrastText }}>
                <PrIcon height={22} width={22} fill="currentColor" />
              </ListItemIcon>
              <ListItemText primary="Pull Requests" />
            </ListItemButton>
          </ListItemStyled>
          <ListItemStyled
            disablePadding
            selected={routerState.location.pathname === '/regression'}
            $drawerOpen={drawerOpen}
          >
            <ListItemButton href="regression" LinkComponent={LinkWrapper}>
              <ListItemIcon sx={{ minWidth: 36, color: (theme) => theme.palette.primary.contrastText }}>
                <TrendingUpIcon />
              </ListItemIcon>
              <ListItemText primary="Regression" />
            </ListItemButton>
          </ListItemStyled>
          <ListItemStyled disablePadding selected={routerState.location.pathname === '/cicd'} $drawerOpen={drawerOpen}>
            <ListItemButton href="cicd" LinkComponent={LinkWrapper} disabled>
              <ListItemIcon sx={{ minWidth: 36, color: (theme) => theme.palette.primary.contrastText }}>
                <AllInclusiveIcon />
              </ListItemIcon>
              <ListItemText primary="CI/CD" />
            </ListItemButton>
          </ListItemStyled>
          <ListItemStyled
            disablePadding
            selected={routerState.location.pathname === '/coverage'}
            $drawerOpen={drawerOpen}
          >
            <ListItemButton href="coverage" LinkComponent={LinkWrapper} disabled>
              <ListItemIcon sx={{ minWidth: 36, color: (theme) => theme.palette.primary.contrastText }}>
                <PercentIcon />
              </ListItemIcon>
              <ListItemText primary="Coverage" />
            </ListItemButton>
          </ListItemStyled>
        </List>
        <Box sx={{ flexGrow: 1 }}></Box>
        <Divider />
        <List>
          <ListItem disablePadding>
            <ListItemButton sx={{ color: additionalPalette.leftDrawerListItemReportBugButtonColor }}>
              <ListItemIcon sx={{ minWidth: 36, color: additionalPalette.leftDrawerListItemReportBugIconColor }}>
                <BugReportIcon />
              </ListItemIcon>
              <ListItemText primary="Report a Bug" />
            </ListItemButton>
          </ListItem>
        </List>
      </Drawer>
      <Box component="main" flexGrow={1} pt={6}>
        <Breadcrumbs crumbs={breadcrumbs} />
        <Container sx={{ py: 6 }} maxWidth="xl">
          <Outlet />
        </Container>
      </Box>
    </Box>
  )
}
