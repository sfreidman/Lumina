import { BuildStatus } from '../enums/build-status'
import { Pagination } from './pagination'

export interface PullRequest {
  id: number
  title: string
  pr_owners: PROwner[]
  target_branch: string
  branch_name: string
  pr_labels: Array<PullRequestLabel>
  github_link: string
  github_status: GithubStatus
  latest_build_sha: string
  latest_build_status: BuildStatus
  latest_build_url: string
  latest_build_id: number
  latest_build_run_id: number
}
export interface PullRequestAPI extends PullRequest {
  created_time: number
  closed_time: number | null
  latest_commit: number
}

export interface PullRequestUI extends PullRequest {
  created_time: Date
  closed_time: Date | null
  latest_commit: Date
}

export interface PROwner {
  user_name: string
  role: PROwnerRole
}

export interface PrFilters {
  owners: Array<string>
  target_branches: Array<string>
  labels: Array<string>
}

export interface PullRequestLabel {
  name: string
  color: string
}

export interface PullRequestPaginationAPI extends Pagination<PullRequestAPI> {
  open_prs: number
}

export interface PullRequestPaginationUI extends Pagination<PullRequestUI> {
  open_prs: number
}

export enum GithubStatus {
  open = 'open',
  merged = 'merged',
}

export enum PROwnerRole {
  REVIEWER = 'reviewer',
  AUTHOR = 'author',
  ASSIGNEE = 'assignee',
}
