export interface Commit {
  id: number
  message: string
  sha: string
  merge_base_sha: string | null
  submitted_time: Date
}
