import { BuildStatus } from '../enums/build-status'

export interface BuildRun {
  id: number
  sha: string
  message: string
}

export interface BuildRunAPI extends BuildRun {
  submitted_time: number
  related_builds: RelatedBuildAPI[]
}

export interface BuildRunUI extends BuildRun {
  submitted_time: Date
  related_builds: RelatedBuildUI[]
}

export interface RelatedBuild {
  build_id: number
  build_run_id: number
  build_status: BuildStatus
  build_url: string
}

export interface RelatedBuildAPI extends RelatedBuild {
  start_time: number
}

export interface RelatedBuildUI extends RelatedBuild {
  start_time: Date
}
