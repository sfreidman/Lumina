export enum OutageState {
  ACTIVE = 'active',
  RELEVANT = 'relevant',
}

export enum OutageStatus {
  IN_PROGRESS = 'in-progress',
  SCHEDULED = 'scheduled',
}

interface Outage {
  id: number
  title: string
  status: OutageStatus
  message_text: string | null
  impact: string | null
  ar: string | null
  root_cause: string | null
  solution: string | null
}

export interface OutageAPI extends Outage {
  start_time: number | null
  end_time: number | null
  submitted_time: number | null
}

export interface OutageUI extends Outage {
  start_time: Date | null
  end_time: Date | null
  submitted_time: Date | null
}
