export interface Pagination<T> {
  results: T[]
  count: number
}
