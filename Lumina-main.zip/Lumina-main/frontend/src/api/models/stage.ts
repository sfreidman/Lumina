import { BuildStatus } from '../enums/build-status'

export interface Stage {
  stage_id: number
  stage_name: string
  stage_status: BuildStatus
  exit_code: number
  exit_code_description: string
  num_pass_tests: number
  num_failed_tests: number
  num_skipped_tests: number
  platform: string
  board_label: string
  junit_path: string
  type: StageStatusType
}

export interface StageAPI extends Stage {
  start_time: number
  end_time: number
  children: StageAPI[]
  tries: StageTryAPI[]
}

export interface StageUI extends Stage {
  start_time: Date
  end_time: Date
  children: StageUI[]
  tries: StageTryUI[]
}

export interface StageTry {
  try_id: number
  exit_code: number
  board_ip: string
  allocation_id: number
  junit_exists: number
}

export interface StageTryAPI extends StageTry {
  body_start_time: number
  body_end_time: number
}

export interface StageTryUI extends StageTry {
  body_start_time: Date
  body_end_time: Date
}

export enum StageStatusType {
  STAGE = 'STAGE',
  WRAPPER = 'WRAPPER',
  TRIGGER = 'TRIGGER',
}
