import { ApiResponse } from './api-types'

type FetchRequestParamsBase = {
  url: string
  accessToken?: string
  queryParams?: URLSearchParams
}

type FetchRequestParamsWithMethod = FetchRequestParamsBase & {
  fetchParams?: RequestInit
}

type FetchRequestParamsNoMethod = FetchRequestParamsBase & {
  fetchParams?: Omit<RequestInit, 'method'>
}

const fetchApi = async <T>({ url, accessToken, queryParams, fetchParams = {} }: FetchRequestParamsWithMethod) => {
  // Remove leading and trailing slashes from the url
  if (url.startsWith('/')) {
    url = url.slice(1)
  }
  if (url.endsWith('/')) {
    url = url.slice(0, -1)
  }

  if (accessToken) {
    fetchParams.headers = {
      ...fetchParams.headers,
      Authorization: `Bearer ${accessToken}`,
    }
  } else {
    console.log('No access token provided')
  }
  url = queryParams ? `${url}/?${queryParams}` : `${url}/`
  const res = await fetch(`${import.meta.env.VITE_API_URL}/${url}`, fetchParams)

  if (!res.ok) {
    const contentType = res.headers.get('content-type')
    if (!contentType || !contentType.includes('application/json')) {
      console.error(`An error occurred: ${res.statusText}`)
      throw new Error(`An error occurred: ${res.statusText}`)
    } else {
      const resBody = (await res.json()) as ApiResponse
      if (resBody.success === false) {
        const errorMessage = resBody.errors.map((error) => error.message).join(', ')
        // TODO: Need to decide if we want to show a toast on each error
        console.error(`An error occurred: ${errorMessage}`)
        throw new Error(`An error occurred: ${errorMessage}`)
      }
    }
  }

  const resBody = (await res.json()) as ApiResponse<T>
  if (resBody.success === true) {
    return resBody.data
  }

  // If we get here without returning or throwing, we have an unexpected error
  // TODO: Need to decide if we want to show a toast on each error
  console.error('An unexpected error occurred')
  throw new Error('An unexpected error occurred')
}

export const getFromApi = async <T>({
  url,
  accessToken,
  queryParams,
  fetchParams = {},
}: FetchRequestParamsNoMethod) => {
  ;(fetchParams as RequestInit).method = 'GET'
  return fetchApi<T>({ url, accessToken, queryParams, fetchParams })
}

export const postToApi = async <T>({ url, accessToken, fetchParams = {} }: FetchRequestParamsNoMethod) => {
  ;(fetchParams as RequestInit).method = 'POST'
  return fetchApi<T>({ url, accessToken, fetchParams })
}

export const patchToApi = async <T>({ url, accessToken, fetchParams = {} }: FetchRequestParamsNoMethod) => {
  ;(fetchParams as RequestInit).method = 'PATCH'
  return fetchApi<T>({ url, accessToken, fetchParams })
}

export const putToApi = async <T>({ url, accessToken, fetchParams = {} }: FetchRequestParamsNoMethod) => {
  ;(fetchParams as RequestInit).method = 'PUT'
  return fetchApi<T>({ url, accessToken, fetchParams })
}

export const deleteFromApi = async <T>({ url, accessToken, fetchParams = {} }: FetchRequestParamsNoMethod) => {
  ;(fetchParams as RequestInit).method = 'DELETE'
  return fetchApi<T>({ url, accessToken, fetchParams })
}
