import { pythonTimestampToJsDate } from '../../utils'
import { StageAPI, StageTryAPI, StageTryUI, StageUI } from '../models/stage'

export function stageSerializer(stage: StageAPI) {
  const children = stage.children.map((subStage) => stageSerializer(subStage)) as StageUI[]
  return {
    stage_id: stage.stage_id,
    stage_name: stage.stage_name,
    stage_status: stage.stage_status,
    exit_code: stage.exit_code,
    exit_code_description: stage.exit_code_description,
    num_pass_tests: stage.num_pass_tests,
    num_failed_tests: stage.num_failed_tests,
    num_skipped_tests: stage.num_skipped_tests,
    platform: stage.platform,
    board_label: stage.board_label,
    junit_path: stage.junit_path,
    type: stage.type,
    start_time: stage.start_time !== null ? pythonTimestampToJsDate(stage.start_time) : undefined,
    end_time: stage.end_time !== null ? pythonTimestampToJsDate(stage.end_time) : undefined,
    children,
    tries: stage.tries.map((stageTry: StageTryAPI) => stageTrySerializer(stageTry)),
  } as StageUI
}

export const stageTrySerializer = (stageTry: StageTryAPI) => {
  return {
    try_id: stageTry.try_id,
    exit_code: stageTry.exit_code,
    board_ip: stageTry.board_ip,
    allocation_id: stageTry.allocation_id,
    junit_exists: stageTry.junit_exists,
    body_start_time: stageTry.body_start_time !== null ? pythonTimestampToJsDate(stageTry.body_start_time) : undefined,
    body_end_time: stageTry.body_end_time !== null ? pythonTimestampToJsDate(stageTry.body_end_time) : undefined,
  } as StageTryUI
}
