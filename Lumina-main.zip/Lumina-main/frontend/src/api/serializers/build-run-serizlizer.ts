import { pythonTimestampToJsDate } from '../../utils'
import { BuildRunAPI, BuildRunUI, RelatedBuildAPI, RelatedBuildUI } from '../models/build-runs'

export const buildRunSerializer = (buildRun: BuildRunAPI) => {
  return {
    id: buildRun.id,
    sha: buildRun.sha,
    message: buildRun.message,
    related_builds: buildRun.related_builds.map((rb) => relatedBuildSerializer(rb)),
    submitted_time: buildRun.submitted_time !== null && pythonTimestampToJsDate(buildRun.submitted_time),
  } as BuildRunUI
}

export const relatedBuildSerializer = (relatedBuild: RelatedBuildAPI) => {
  return {
    build_run_id: relatedBuild.build_run_id,
    build_status: relatedBuild.build_status,
    build_url: relatedBuild.build_url,
    start_time: relatedBuild.start_time !== null && pythonTimestampToJsDate(relatedBuild.start_time),
  } as RelatedBuildUI
}
