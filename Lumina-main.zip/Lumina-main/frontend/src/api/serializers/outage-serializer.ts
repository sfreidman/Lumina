import { pythonTimestampToJsDate } from '../../utils'
import { OutageAPI, OutageUI } from '../models/outage'

export const outageSerializer = (outage: OutageAPI) => {
  return {
    id: outage.id,
    title: outage.title,
    start_time: outage.start_time !== null && pythonTimestampToJsDate(outage.start_time),
    end_time: outage.end_time !== null && pythonTimestampToJsDate(outage.end_time),
    submitted_time: outage.submitted_time !== null && pythonTimestampToJsDate(outage.submitted_time),
    status: outage.status,
    message_text: outage.message_text,
    impact: outage.impact,
    ar: outage.ar,
    root_cause: outage.root_cause,
    solution: outage.solution,
  } as OutageUI
}
