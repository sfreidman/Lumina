import { pythonTimestampToJsDate } from '../../utils'
import { PullRequestAPI, PullRequestUI } from '../models/pull-request'

export const pullRequestSerializer = (pr: PullRequestAPI) => {
  return {
    id: pr.id,
    title: pr.title,
    pr_owners: pr.pr_owners,
    target_branch: pr.target_branch,
    branch_name: pr.branch_name,
    pr_labels: pr.pr_labels,
    github_link: pr.github_link,
    github_status: pr.github_status,
    latest_build_sha: pr.latest_build_sha,
    latest_build_id: pr.latest_build_id,
    latest_build_run_id: pr.latest_build_run_id,
    latest_build_status: pr.latest_build_status,
    latest_build_url: pr.latest_build_url,
    created_time: pr.created_time !== null && pythonTimestampToJsDate(pr.created_time),
    closed_time: pr.closed_time !== null && pythonTimestampToJsDate(pr.closed_time),
    latest_commit: pr.latest_commit !== null && pythonTimestampToJsDate(pr.latest_commit),
  } as PullRequestUI
}
