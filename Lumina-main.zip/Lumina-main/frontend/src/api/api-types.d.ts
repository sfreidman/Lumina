export type ApiResponse<T = unknown> =
  | {
      success: true
      version: string
      data: T
    }
  | {
      success: false
      version: string
      errors: {
        message: string
        code: string
      }[]
      trace?: string
    }

export type User = {
  id: string
  email: string
  first_name: string
  last_name: string
  groups: string[]
}
