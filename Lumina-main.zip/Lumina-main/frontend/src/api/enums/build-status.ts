export enum BuildStatus {
  success = 'success',
  aborted = 'aborted',
  unstable = 'unstable',
  failure = 'failure',
  in_progress = 'in_progress',
  skipped = 'skipped',
  scheduled = 'scheduled',
}
