import base64
import hashlib
import os
import random
import re
import string


def main():
    code_verifier = base64.urlsafe_b64encode(os.urandom(60)).decode("utf-8")
    code_challenge = hashlib.sha256(code_verifier.encode("utf-8")).digest()
    code_challenge = base64.urlsafe_b64encode(code_challenge).decode("utf-8")
    code_challenge = code_challenge.replace("=", "")
    print("code_verifier: " + code_verifier)
    print("code_challenge: " + code_challenge)


if __name__ == "__main__":
    main()
