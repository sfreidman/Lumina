from drf_spectacular.openapi import AutoSchema, OpenApiExample
from drf_spectacular.plumbing import get_class
from drf_spectacular.utils import extend_schema_serializer
from rest_framework import serializers


class ErrorSerializer(serializers.Serializer):
    message = serializers.CharField()
    code = serializers.CharField()


def enveloper(serializer_class, many):
    component_name = "Enveloped{}{}".format(
        serializer_class.__name__.replace("Serializer", ""),
        "List" if many else "",
    )

    if serializer_class == type(None):
        serializer_class_or_fallback = serializers.DictField(required=False)
        component_name = "EnvelopedDict"
    else:
        serializer_class_or_fallback = serializer_class(many=many, required=False)

    @extend_schema_serializer(
        many=False,
        component_name=component_name,
    )
    class EnvelopeSerializer(serializers.Serializer):
        success = serializers.BooleanField()
        version = serializers.CharField()
        data = serializer_class_or_fallback
        errors = ErrorSerializer(many=True, required=False)

    return EnvelopeSerializer


class EnvelopedAutoSchema(AutoSchema):
    def get_response_serializers(self):
        """use envelope on all default responses. @extend_schema will override this change"""
        serializer_class = get_class(self._get_serializer())
        return enveloper(serializer_class=serializer_class, many=self._is_list_view(serializer_class))
