from django.urls import path

from apps.core.views import HealthCheck

urlpatterns = [
    path("health-check/", HealthCheck.as_view(), name="health-check"),
]
