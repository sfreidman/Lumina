from datetime import datetime
import pytz


def date_to_unix_timestamp(date_str: str) -> int:
    """
    Convert a UTC date string in the format "YYYY-MM-DDTHH:MM:SSZ" to a Unix timestamp.

    :param date_str: The UTC date string.
    :return: Unix timestamp as an integer.
    """
    if not date_str:
        return None
    # Parse the date string to a datetime object
    date_obj = datetime.strptime(date_str, "%Y-%m-%dT%H:%M:%SZ")
    # Set timezone to UTC
    date_obj = date_obj.replace(tzinfo=pytz.utc)
    # Convert to Unix timestamp
    unix_timestamp = int(date_obj.timestamp())

    return unix_timestamp


def get_hash_id(str_value: str) -> int:
    if not str_value:
        return None
    hash_unique_id = 0
    for ch in str_value:
        hash_unique_id = (hash_unique_id * 281 ^ ord(ch) * 997) & 0xFFFFFFFF
    return hash_unique_id


def quote_comma_separated_values(s: str) -> str:
    # Split the string into a list by commas
    values = s.split(",")
    # Enclose each value in single quotes and join them back into a string
    quoted_values = ",".join([f"'{value}'" for value in values])
    return quoted_values


def format_stage_name(s):
    # Split the string by underscores, capitalize each word, and join with spaces
    return " ".join(word.capitalize() for word in s.split("_"))
