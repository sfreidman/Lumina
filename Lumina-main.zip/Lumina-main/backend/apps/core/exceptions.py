import traceback

from django.conf import settings
from django.core.exceptions import PermissionDenied
from django.http import Http404
from rest_framework.exceptions import ErrorDetail
from rest_framework.views import Response, exceptions, set_rollback


# TODO: Once we have legit codes we can display them here
class CustomApiExceptionCodes:
    some_error_code = "some_error_code"


def custom_exception_handler(exc, context):
    """
    MODIFIED VERSION OF rest_framework.views.exception_handler

    By default we handle the REST framework `APIException`, and also
    Django's built-in `Http404` and `PermissionDenied` exceptions.

    Any unhandled exceptions may return `None`, which will cause a 500 error
    to be raised.
    """
    if isinstance(exc, Http404):
        exc = exceptions.NotFound()
    elif isinstance(exc, PermissionDenied):
        exc = exceptions.PermissionDenied()

    if isinstance(exc, exceptions.APIException):
        headers = {}
        errors = []
        if getattr(exc, "auth_header", None):
            headers["WWW-Authenticate"] = exc.auth_header
        if getattr(exc, "wait", None):
            headers["Retry-After"] = "%d" % exc.wait

        if isinstance(exc.detail, (list, dict)):
            if isinstance(exc.detail, dict):
                for key, value in exc.detail.items():
                    errors = get_internal_errors(key, value)
            else:
                for value in exc.detail:
                    errors = get_internal_errors(None, value)
        else:
            error = {
                "message": str(exc.detail),
                "code": exc.detail.code,
            }
            errors.append(error)

        set_rollback()

        if settings.DEBUG:
            trace = "".join(traceback.format_exception(type(exc), value=exc, tb=exc.__traceback__))  # type: ignore
            return Response({"errors": errors, "trace": trace}, status=exc.status_code, headers=headers)
        else:
            return Response({"errors": errors}, status=exc.status_code, headers=headers)

    return None


def get_internal_errors(error_key: str, error_details: list[ErrorDetail] | ErrorDetail):
    errors = []
    if isinstance(error_details, (list)):
        # Nested validation exceptions are weird
        for sub_value in error_details:
            error = {
                "message": f"{error_key}: {sub_value}" if error_key else sub_value,
                "code": sub_value.code,
            }
            errors.append(error)
    else:
        error = {
            "message": f"{error_key}: {error_details}" if error_key else error_details,
            "code": error_details.code,
        }
        errors.append(error)
    return errors
