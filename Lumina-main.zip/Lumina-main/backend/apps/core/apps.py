from django.apps import AppConfig


class CoreConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    label = "core"
    name = "apps.core"
    verbose_name = "Core"
