from django.conf import settings
from rest_framework.renderers import JSONRenderer


class EnvelopeJsonRenderer(JSONRenderer):
    def render(self, data, accepted_media_type=None, renderer_context=None):
        response = renderer_context.get("response")
        wrapped_data = {"success": True, "data": data, "version": settings.API_VERSION}

        if response is not None and response.status_code >= 400:
            del wrapped_data["data"]
            wrapped_data["success"] = False

            if "errors" in data:
                wrapped_data["errors"] = data["errors"]
            if "trace" in data:
                wrapped_data["trace"] = data["trace"]

        return super(EnvelopeJsonRenderer, self).render(wrapped_data, accepted_media_type, renderer_context)
