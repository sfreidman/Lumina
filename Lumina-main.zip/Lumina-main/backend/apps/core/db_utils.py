from django.db import connection
import logging
from rest_framework.exceptions import APIException
from django.db import models

logger = logging.getLogger(__name__)


def execute_db_query(query, params=None):
    try:
        with connection.cursor() as cursor:
            cursor.execute(query, params)
            # Fetch the column headers
            columns = [col[0] for col in cursor.description]
            # Fetch all rows, and construct a dict for each row
            rows = [dict(zip(columns, row)) for row in cursor.fetchall()]
            return rows
    except Exception as e:
        logger.error(f"MySQL query execution error: {e}; query: {query}")
        raise APIException(f"MySQL query execution error: {e}; query: {query}")


class UnixTimestamp(models.Func):
    function = "UNIX_TIMESTAMP"
    template = "%(function)s()"
    output_field = models.IntegerField()
