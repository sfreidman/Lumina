from django.db import connection
from rest_framework import serializers
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView
from django.core.cache import cache
import random


class HealthCheckSerializer(serializers.Serializer):
    is_cache_healthy = serializers.BooleanField()
    is_db_healthy = serializers.BooleanField()


class HealthCheck(APIView):
    authentication_classes = []
    permission_classes = [AllowAny]

    # This is used by drf-spectacular lib to generate Swagger specs
    serializer_class = HealthCheckSerializer

    def get(self, request, format=None):
        try:
            with connection.cursor() as cursor:
                cursor.execute("SELECT 1")
                is_db_healthy = True
        except Exception as ex:
            is_db_healthy = False

        random_number = random.randint(1, 1000)
        random_key = f"health_check_{random_number}"
        cache.set(random_key, random_number, timeout=1)
        redis_number = cache.get(random_key)

        is_cache_healthy = random_number == redis_number
        return Response(
            self.serializer_class({"is_cache_healthy": is_cache_healthy, "is_db_healthy": is_db_healthy}).data,
            status=200 if is_cache_healthy and is_db_healthy else 500,
            content_type="application/json",
        )
