from abc import ABC


class BaseDTO(ABC):
    def to_dict(self) -> dict:
        return vars(self)
