from django.urls import path
from apps.outages.views import OutageMessageView


urlpatterns = [
    path("", OutageMessageView.as_view(), name="outages"),
]
