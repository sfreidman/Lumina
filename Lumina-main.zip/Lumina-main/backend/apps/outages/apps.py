from django.apps import AppConfig


class OutageConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    label = "outages"
    name = "apps.outages"
    verbose_name = "Outage Messages"
