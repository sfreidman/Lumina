import logging

from rest_framework.exceptions import APIException
from django.utils import timezone
from datetime import timedelta
from .models import OutageMessage
from apps.pull_requests.models import Build
from django.db.models.functions import Coalesce
from apps.core.db_utils import UnixTimestamp
from django.db.models import Q

logger = logging.getLogger(__name__)


def get_active_outage_messages() -> list[OutageMessage]:
    try:
        # Get the current timestamp in UTC
        now_timestamp = timezone.now()
        # Convert to UNIX timestamp (seconds since epoch)
        now_unix_timestamp = int(now_timestamp.timestamp())
        # Calculate UNIX timestamp for 3 days ahead
        three_days_ahead_unix_timestamp = int((now_timestamp + timedelta(days=3)).timestamp())

        # case when status ='scheduled' and from_UNIXTIME(start_time)<NOW() then 'in-progress' else status end as
        outage_messages = OutageMessage.objects.raw(
            """
            SELECT id, message_text, start_time,end_time, impact ,ar, solution, title, status
            FROM outage_messages
            WHERE status='in-progress'
            OR (
                end_time > %s
                AND start_time < %s
                AND status='scheduled'
            )
        """,
            [now_unix_timestamp, three_days_ahead_unix_timestamp],
        )

        outage_messages_list = list(outage_messages)
        return outage_messages_list
    except:
        logging.error(f"Failed to get list of active messages.")
        raise APIException(f"Failed to get list of active messages.")


def get_relevant_outage_messages(build_run_id: int, pr_id: int) -> list[OutageMessage]:

    build = (
        Build.objects.filter(build_run_id=build_run_id, job_name="sdk-pr-main", pr_id=pr_id)
        .annotate(real_end_time=Coalesce("end_time", UnixTimestamp()))
        .first()
    )

    if not build:
        return []

    build_start = build.start_time
    build_end = build.real_end_time

    # Query OutageMessages where there's an intersection with the build period
    outage_messages = OutageMessage.objects.annotate(real_end_time=Coalesce("end_time", UnixTimestamp())).filter(
        Q(start_time__lte=build_end, real_end_time__gte=build_start)
    )

    return list(outage_messages)
