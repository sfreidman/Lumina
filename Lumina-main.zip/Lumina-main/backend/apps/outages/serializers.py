from django.utils import timezone
from rest_framework import serializers
from .models import OutageMessage
from rest_framework.exceptions import ValidationError


class OutageMessageSerializer(serializers.ModelSerializer):
    status = serializers.SerializerMethodField()

    class Meta:
        model = OutageMessage
        fields = ("id", "message_text", "start_time", "end_time", "impact", "ar", "solution", "title", "status")

    def get_status(self, obj):
        """Custom method to determine the status based on start_time, end_time, and current status."""
        current_time = timezone.now().timestamp()
        start_time = obj.start_time

        # Check conditions to determine status
        print(f" {obj.status} {start_time} {current_time} ")
        if obj.status == "scheduled" and start_time < current_time:
            return "in-progress"
        return obj.status


class OutageMessageParamsSerializer(serializers.Serializer):
    state = serializers.ChoiceField(choices=["active", "relevant"], required=True)
    build_run_id = serializers.IntegerField(required=False, help_text="Build run id affected by outages")
    pr_id = serializers.IntegerField(required=False, help_text="Build run id affected by outages")

    def validate(self, data):

        state = data.get("state")
        build_run_id = data.get("build_run_id")
        pr_id = data.get("pr_id")

        # If state is 'relevant', then build_id must be provided
        if state == "relevant":
            if build_run_id is None:
                raise ValidationError("build run id is required when state is 'relevant'.")
            if pr_id is None:
                raise ValidationError("pr id is required when state is 'relevant'.")

        return data
