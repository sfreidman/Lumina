from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.outages.services import get_active_outage_messages, get_relevant_outage_messages
from drf_spectacular.utils import extend_schema
from .serializers import OutageMessageSerializer, OutageMessageParamsSerializer


class OutageMessageView(APIView):
    # TODO add permissions handling
    authentication_classes = []
    permission_classes = [AllowAny]
    serializer_class = OutageMessageSerializer

    @extend_schema(parameters=[OutageMessageParamsSerializer])
    def get(self, request):
        params_serializer = OutageMessageParamsSerializer(data=request.query_params)
        params_serializer.is_valid(raise_exception=True)

        state = params_serializer.validated_data.get("state")
        if state == "active":
            outage_messages = get_active_outage_messages()

        elif state == "relevant":
            outage_messages = get_relevant_outage_messages(
                build_run_id=params_serializer.validated_data.get("build_run_id"),
                pr_id=params_serializer.validated_data.get("pr_id"),
            )

        serializer = OutageMessageSerializer(outage_messages, many=True)
        return Response(serializer.data, status=200)
