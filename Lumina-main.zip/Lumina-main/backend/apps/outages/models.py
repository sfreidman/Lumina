from django.conf import settings
from django.db import models


class OutageMessage(models.Model):
    message_text = models.TextField()
    start_time = models.IntegerField(null=True, blank=True)
    end_time = models.IntegerField(null=True, blank=True)
    submitted_time = models.IntegerField(null=True, blank=True)
    status = models.CharField(max_length=45, null=True, blank=True)
    impact = models.TextField(null=True, blank=True)
    ar = models.TextField(null=True, blank=True, verbose_name="Action Required")
    root_cause = models.TextField(null=True, blank=True)
    solution = models.TextField(null=True, blank=True)
    title = models.CharField(max_length=100, null=True, blank=True)

    class Meta:
        db_table = "outage_messages"
