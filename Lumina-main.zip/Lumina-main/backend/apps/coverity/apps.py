from django.apps import AppConfig


class Coverity(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    label = "coverity"
    name = "apps.coverity"
    verbose_name = "Coverity"
