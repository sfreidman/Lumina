from rest_framework import serializers
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.core.utils import *
from apps.coverity.dtos import CovSnapshotDto
from apps.coverity.services import get_cov_snapshot_info, save_cov_snapshot_info


class CovSnapshot(APIView):
    # TODO add permissions handling for request from github
    authentication_classes = []
    permission_classes = [AllowAny]

    def post(data, request, format=None):
        json_data = request.data
        cov_snapshot = CovSnapshotDto(json_data)
        save_cov_snapshot_info(cov_snapshot)
        return Response({"status": "Received"}, status=200)

    def get(self, request):
        cov_snapshot_data = get_cov_snapshot_info(
            sha=request.query_params.get("sha"), platform=request.query_params.get("platform")
        )
        if cov_snapshot_data:
            # Successful retrieval, cov_snapshot_data is a dict
            return Response(cov_snapshot_data, status=201)
        else:
            # cov_snapshot_data is None, indicating not found
            return Response({"error": "Snapshot not found"}, status=404)
