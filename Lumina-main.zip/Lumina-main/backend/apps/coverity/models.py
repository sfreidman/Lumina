from django.conf import settings
from django.db import models


class CoveritySnapshot(models.Model):
    id = models.BigIntegerField(primary_key=True)
    sha = models.CharField(max_length=80, null=False)
    snapshot_id = models.IntegerField(null=True, blank=True, default=None)
    exact_match = models.BooleanField(null=True, blank=True, default=None)
    platform = models.CharField(max_length=10, null=False)
    stream_name = models.CharField(max_length=160, null=True, blank=True, default=None)

    class Meta:
        db_table = "cov_snapshots"
