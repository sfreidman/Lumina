from apps.core.dtos import BaseDTO
from apps.core.utils import *
from apps.core.utils import date_to_unix_timestamp


class CovSnapshotDto(BaseDTO):
    def __init__(self, json_data: dict):
        self.id = get_hash_id(f"{json_data["sha"]},{json_data["platform"]}")
        self.sha = json_data["sha"]
        self.platform =json_data["platform"]
        self.snapshot_id =json_data["snapshot_id"]
        self.exact_match =json_data["exact_match"]
        self.stream_name =json_data["stream_name"]
