import logging

from django.db import IntegrityError
from django.forms.models import model_to_dict
from django.http import JsonResponse
from rest_framework.views import exceptions

from apps.core.utils import *
from apps.coverity.dtos import CovSnapshotDto

from .models import CoveritySnapshot

logger = logging.getLogger(__name__)


def save_cov_snapshot_info(cov_snapshot: CovSnapshotDto):
    # TODO: handle permissions at some point
    try:
        CoveritySnapshot.objects.update_or_create(id=cov_snapshot.id, defaults=cov_snapshot.to_dict())
        logging.debug(
            f"Coverity data for sha {cov_snapshot.sha} and platform {cov_snapshot.platform}  was sucessfuly updated in db."
        )
    except Exception as e:
        logging.error(
            f"An unexpected error occurred while updating coverity data for sha {cov_snapshot.sha} and platform {cov_snapshot.platform} : {e}"
        )
        raise exceptions.APIException()


def get_cov_snapshot_info(sha: str, platform: str) -> dict:
    cov_snapshot_id = get_hash_id(f"{sha},{platform}")
    try:
        cov_snapshot = CoveritySnapshot.objects.get(id=cov_snapshot_id)
        return model_to_dict(cov_snapshot)
    except CoveritySnapshot.DoesNotExist:
        logging.error(f"Coverity snapshot for sha {sha} and platform {platform} was not found in DB.")
        raise exceptions.APIException()
