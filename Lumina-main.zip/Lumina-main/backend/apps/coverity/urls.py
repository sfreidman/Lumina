from django.urls import path
from apps.coverity.views import CovSnapshot


urlpatterns = [
    path("snapshots/", CovSnapshot.as_view(), name="snapshots"),
]
