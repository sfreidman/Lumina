def create_groups_and_permissions(sender, **kwargs):
    # This must be here, otherwise we get "AppRegistryNotReady: Apps aren't loaded yet." error
    from django.conf import settings
    from django.contrib.auth.models import Group, Permission

    # Create groups if they don't exist
    Group.objects.get_or_create(name=settings.ADMINS_GROUP_NAME)
    Group.objects.get_or_create(name=settings.USERS_GROUP_NAME)
