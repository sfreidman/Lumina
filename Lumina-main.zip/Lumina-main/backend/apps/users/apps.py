from django.apps import AppConfig
from django.db.models.signals import post_migrate

from apps.users.signals import create_groups_and_permissions


class UsersConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    label = "users"
    name = "apps.users"
    verbose_name = "Users"

    def ready(self):
        post_migrate.connect(create_groups_and_permissions, sender=self)
