from django.conf import settings
from django.db.models import Q
from rest_framework import permissions


class IsAdminGroupPermission(permissions.BasePermission):
    """
    This is an elevated permission, to assign to admin only endpoints
    """

    def has_permission(self, request, view):
        return request.user.groups.filter(name=settings.ADMINS_GROUP_NAME).exists()


class IsUserGroupPermission(permissions.BasePermission):
    """
    This is the default permission, it contains both user and admin,
    assuming that admins are allowed to do anything that users are allowed.
    """

    def has_permission(self, request, view):
        return request.user.groups.filter(
            Q(name=settings.ADMINS_GROUP_NAME) | Q(name=settings.USERS_GROUP_NAME)
        ).exists()
