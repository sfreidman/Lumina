from django.contrib.auth import get_user_model
from rest_framework import serializers


class UserSerializer(serializers.ModelSerializer):
    groups = serializers.SerializerMethodField()

    class Meta:
        model = get_user_model()
        fields = ["id", "email", "first_name", "last_name", "groups", "cisco_username"]

    def get_groups(self, obj) -> list[str]:
        return [group.name for group in obj.groups.all()]
