import hashlib
import re
import time

from django.conf import settings
from django.contrib.auth.models import Group
from django.core.cache import cache
from drf_spectacular.extensions import OpenApiAuthenticationExtension
from drf_spectacular.plumbing import build_bearer_security_scheme_object
from mozilla_django_oidc.auth import OIDCAuthenticationBackend


# This is purely for the OpenAPI schema
class OIDCScheme(OpenApiAuthenticationExtension):
    target_class = "mozilla_django_oidc.contrib.drf.OIDCAuthentication"
    name = "oidcToken"
    match_subclasses = True
    priority = -1

    def get_security_definition(self, auto_schema):
        return build_bearer_security_scheme_object(
            header_name="Authorization",
            token_prefix="Bearer",
        )


class OIDCAuthenticationBackend(OIDCAuthenticationBackend):
    def get_token(self, payload):
        """Return the token from the payload."""
        del payload["client_secret"]
        return super().get_token(payload)

    def get_user(self, user_id):
        """Return a user based on the id."""
        try:
            user = self.UserModel.objects.get(pk=user_id)
        except self.UserModel.DoesNotExist:
            return None

        return user if self.user_can_authenticate(user) else None

    def create_user(self, claims):
        """Return object for a newly created user account."""
        username = claims.get("user")
        email = claims.get("email")
        first_name = claims.get("first_name")
        last_name = claims.get("last_name")

        user = self.UserModel.objects.create_user(
            username, email=email, first_name=first_name, last_name=last_name, cisco_username=username
        )
        self._update_user_groups(user, claims)
        return user

    def update_user(self, user, claims):
        """Update existing user with new claims, if necessary save, and return user"""
        first_name = claims.get("first_name")
        last_name = claims.get("last_name")

        if not first_name or not last_name:
            raise ValueError("Both first and last names are required")

        if first_name != user.first_name or last_name != user.last_name:
            user.first_name = first_name
            user.last_name = last_name
            user.save()

        self._update_user_groups(user, claims)
        return user

    def get_userinfo(self, access_token, id_token, payload):
        """This function wraps the internal get_userinfo function to cache the result.
        It is especially useful with REST API, where we want to avoid multiple userinfo requests."""

        short_cache_key = hashlib.sha256(access_token.encode("utf-8")).hexdigest()
        userinfo = cache.get(short_cache_key)
        if not userinfo:
            if not payload:
                payload = self.verify_token(access_token)

            userinfo = super().get_userinfo(access_token, id_token, payload)

            # cache until the access_token should expire
            access_token_expiration = payload.get("exp")
            access_token_expires_in_seconds = access_token_expiration - int(time.time())
            cache.set(short_cache_key, userinfo, timeout=access_token_expires_in_seconds)
        return userinfo

    def _update_user_groups(self, user, claims):
        """Update user groups based on claims"""
        re_compiled = re.compile(r"CN=([^,]+)")
        groups_claim = claims.get("groups", [])

        claim_group_names = {re_compiled.search(group).group(1) for group in groups_claim}
        db_user_group_names = {group.name: group for group in user.groups.all()}
        all_db_groups = {db_group.name: db_group for db_group in Group.objects.all()}

        # TODO: remove this when the SSO groups are properly set up
        if settings.DEBUG:
            claim_group_names.add("cag-sw-cicd-group")

        sso_group_mapping = settings.SSO_GROUP_MAPPING
        reverse_sso_group_mapping = {v: k for k, v in sso_group_mapping.items()}

        for db_group_name in db_user_group_names:
            translated_group_name = reverse_sso_group_mapping[db_group_name]
            if translated_group_name not in claim_group_names:
                user.groups.remove(db_user_group_names[db_group_name])

        for claim_group_name in claim_group_names:
            if claim_group_name in sso_group_mapping:
                translated_group_name = sso_group_mapping[claim_group_name]
                if translated_group_name not in db_user_group_names and translated_group_name in all_db_groups:
                    user.groups.add(all_db_groups[translated_group_name])

        return user
