from django.urls import path

from apps.pull_requests.views import (
    GitHubWebHook,
    PRListFilters,
    PRListData,
    PRRunsData,
    PRDetailsData,
    PRRunStagesData,
    PRLatestCommitDetails,
    PRStableTags2Merge,
    PRPipelineStages,
)

urlpatterns = [
    path("github/", GitHubWebHook.as_view(), name="github_webhook"),
    path("pr-list/filters/", PRListFilters.as_view(), name="pr-list-filters"),
    path("pr-list/", PRListData.as_view(), name="pr-list"),
    path("<int:pr_id>/pr-runs/", PRRunsData.as_view(), name="pr-runs"),
    path("<int:pr_id>/", PRDetailsData.as_view(), name="pr-details"),
    path("<int:pr_id>/pr-runs/<int:build_run_id>/stages-status/", PRRunStagesData.as_view(), name="pr-run-stages"),
    path("<int:pr_id>/commits/latest/", PRLatestCommitDetails.as_view(), name="pr-latest-commit"),
    path("<int:pr_id>/stable-tags/", PRStableTags2Merge.as_view(), name="pr-stable-tags"),
    path("<int:pr_id>/pipeline-stages/", PRPipelineStages.as_view(), name="pr-pipeline-stages"),
]
