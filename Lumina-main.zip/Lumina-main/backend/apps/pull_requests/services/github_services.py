import logging
import os

import requests
from django.conf import settings
from rest_framework.views import exceptions

from apps.core.utils import *
from apps.pull_requests.dtos import PRCommitDto, PRDto, PRLabelDto, PullRequestDto, PROwnerDto

from ..models import Commit, PRLabel, PullRequest, PROwner

logger = logging.getLogger(__name__)


def save_pr_info_all(pr_dto: PullRequestDto):
    save_pr_info(pr_dto.pr)
    save_pr_commits_info(pr_dto.pr)
    for label in pr_dto.labels_dto_list:
        save_pr_label_info(label, "labeled")
    for owner in pr_dto.owners_dto_list:
        save_pr_owner_info(owner, "add_owner")


# This function is designed to insert pull_request data to the database.
def save_pr_info(pr_dto: PRDto):
    try:
        PullRequest.objects.update_or_create(id=pr_dto.id, defaults=pr_dto.to_dict())
        logging.debug(f"PR {pr_dto.id} successfully updated in db.")
    except Exception as e:
        logging.error(f"An unexpected error occurred while updating PR {pr_dto.id}: {e}")
        raise exceptions.APIException()


# This function is designed to save  PR commits data to the database.
def save_pr_commits_info(pr_dto: PRDto):
    commits_url = f"{settings.GITHUB_API_BASE_URL}/pulls/{pr_dto.id}/commits"
    commits_list = get_pr_commits(commits_url, pr_dto.id)
    # Create PR row if it doesn't exists in db
    if not PullRequest.objects.filter(id=pr_dto.id).exists():
        save_pr_info(pr_dto)

    pr = PullRequest.objects.get(id=pr_dto.id)  # Assign the PullRequest instance
    for commit in commits_list:
        try:
            # If Commit already  exists, no need to procedure
            if Commit.objects.filter(id=commit.id).exists():
                break

            commit.merge_base_sha = get_merge_base_sha(pr_dto.target_branch, commit.sha)
            Commit.objects.create(
                pr=pr,
                id=commit.id,
                sha=commit.sha,
                message=commit.message,
                submitted_time=commit.submitted_time,
                merge_base_sha=commit.merge_base_sha,
            )
            logging.debug(f"Commit {commit.sha} for PR {pr.id} sucessfuly added to db.")
        except Exception as e:
            logging.error(f"Failed to insert commit {commit.sha} for PR {pr.id} : {e}.")
            raise exceptions.APIException()


# This function is designed to save  PR label data to the database.
def save_pr_label_info(label: PRLabelDto, action: str):
    if label.name.startswith("run-") or label.name.startswith("skip-"):
        return

    if action == "labeled":
        try:
            pr = PullRequest.objects.get(id=label.pr_id)
            obj, created = PRLabel.objects.get_or_create(pr=pr, name=label.name, defaults={"color": label.color})
            if created:
                logging.debug(f"Label {label.name} for PR-{label.pr_id} sucessfuly added to db.")
        except Exception as e:
            logging.error(f"An unexpected error occurred while updating label {label.name} for PR {label.pr_id}: {e}")
            raise exceptions.APIException()

    elif action == "unlabeled":
        try:
            PRLabel.objects.filter(name=label.name).delete()
            logging.debug(f"Label {label.name} for PR-{label.pr_id}  sucessfuly deleted from db.")
        except Exception as e:
            logging.error(f"An unexpected error occurred while updating lanel {label.name} for PR {label.pr_id}: {e}")
            raise exceptions.APIException()


def save_pr_owner_info(owner: PROwnerDto, action: str):

    if action in ["requested", "assigned", "add_owner"]:
        try:
            pr = PullRequest.objects.get(id=owner.pr_id)
            obj, created = PROwner.objects.get_or_create(pr=pr, user_name=owner.user_name, role=owner.role)
            if created:
                logging.debug(f"Owner {owner.user_name} for PR-{owner.pr_id} sucessfuly added to db.")
        except Exception as e:
            logging.error(
                f"An unexpected error occurred while updating owner {owner.user_name} for PR {owner.pr_id}: {e}"
            )
            raise exceptions.APIException()


# This function is designed to get data about PR commits from GitHub
def get_pr_commits(api_url: str, pr_id: int) -> list[PRCommitDto]:
    pr_commits_data = fetch_github_data(api_url)
    if pr_commits_data:
        commits_list = [PRCommitDto(commit, pr_id) for commit in pr_commits_data]
        sorted_commits_list = sorted(commits_list, key=lambda x: x.submitted_time, reverse=True)
    return sorted_commits_list


def sync_pr_info(pr_list: int):
    for pr_id in pr_list:
        api_url = f"{settings.GITHUB_API_BASE_URL}/pulls/{pr_id}?per_page=5"
        full_pr_data = fetch_github_data(api_url)
        pr_dto = PullRequestDto(full_pr_data)
        save_pr_info_all(pr_dto)


# This function is designed to get data about PR merge_base_commit sha from GitHub
def get_merge_base_sha(base, commit_sha) -> str | None:
    merge_base_sha = None
    get_base_sha_url = f"{settings.GITHUB_API_BASE_URL}/compare/{base}...{commit_sha}"
    base_compare_data = fetch_github_data(get_base_sha_url)
    if base_compare_data:
        merge_base_sha = base_compare_data["merge_base_commit"]["sha"]

    return merge_base_sha


# This function is designed to fetch data from GitHub acording to provided url
def fetch_github_data(api_url, params=None, timeout=100) -> dict | None:
    headers = {"Authorization": "token " + settings.GITHUB_TOKEN}

    try:
        response = requests.get(api_url, headers=headers, params=params, timeout=timeout)
        response.raise_for_status()  # Raises an HTTPError for bad responses
        return response.json()
    except requests.exceptions.HTTPError as e:
        logging.error(f"HTTP error: {e.response.status_code} - {e.response.reason}")
    except requests.exceptions.RequestException as e:
        logging.error(f"Error fetching data from GitHub: {e}")
    return None
