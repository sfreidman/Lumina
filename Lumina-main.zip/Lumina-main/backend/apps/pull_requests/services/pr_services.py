import json
import logging
from django.shortcuts import get_object_or_404
from apps.core.utils import format_stage_name
from apps.core.db_utils import execute_db_query
from apps.pull_requests.dtos import PRCommitsAndRunsDTO
from ..models import Commit, PRLabel, PullRequest, PROwner, Build, StagesRun, ExitCode, StableTag
from django.db.models import Case, When, Value, Max, F, CharField, Prefetch, Q, Subquery, OuterRef
from typing import Dict, List, Tuple
from ..serializers import PRListParamsSerializer


logger = logging.getLogger(__name__)


def get_pr_list_filters() -> Dict[str, List[str]]:
    target_branches = get_distinct_branches()
    labels = get_distinct_labels()
    owners = get_distinct_owners()
    filters = {"owners": owners, "target_branches": target_branches, "labels": labels}
    return filters


def get_distinct_branches() -> List[str]:
    target_branches_list = PullRequest.objects.values_list("target_branch", flat=True).distinct()
    return list(target_branches_list)


def get_distinct_owners() -> List[str]:
    owners_list = PROwner.objects.values_list("user_name", flat=True).distinct()
    return list(owners_list)


def get_distinct_labels() -> List[str]:
    distinct_labels = PRLabel.objects.values_list("name", flat=True).distinct()
    return list(distinct_labels)


def get_pr_list(params: PRListParamsSerializer) -> Tuple[List[PullRequest], int, int]:
    limit = int(params.get("limit", 20))
    offset = int(params.get("offset", 0))
    order_by = params.get("order_by", "-state,-latest_commit")
    order_fields = order_by.split(",")

    query_conditions = Q()
    # Dynamically add conditions based on filters

    target_branch = params.get("target_branch")
    if target_branch:
        query_conditions &= Q(target_branch__in=target_branch.split(","))

    pr_label = params.get("label")
    if pr_label:
        query_conditions &= Q(pr_labels__name__in=pr_label.split(","))

    owner = params.get("owner")
    if owner:
        query_conditions &= Q(pr_owners__user_name__in=owner.split(","))

    title = params.get("title")
    if title:
        query_conditions &= Q(title__icontains=title)

    pr_id = params.get("pr_id")
    if pr_id:
        query_conditions = Q(id=params.get("pr_id"))

    # Subqueries for latest_build_status and latest_build_url
    latest_build_status = (
        Build.objects.filter(pr_id=OuterRef("pk"), job_name="sdk-pr-main")
        .order_by("-start_time")
        .values("build_status")[:1]
    )

    latest_build_url = (
        Build.objects.filter(pr_id=OuterRef("pk"), job_name="sdk-pr-main")
        .order_by("-start_time")
        .values("build_url")[:1]
    )

    latest_build_id = (
        Build.objects.filter(pr_id=OuterRef("pk"), job_name="sdk-pr-main")
        .order_by("-start_time")
        .values("build_id")[:1]
    )

    latest_build_run_id = (
        Build.objects.filter(pr_id=OuterRef("pk"), job_name="sdk-pr-main")
        .order_by("-start_time")
        .values("build_run_id")[:1]
    )
    latest_build_sha = (
        Build.objects.filter(pr_id=OuterRef("pk"), job_name="sdk-pr-main").order_by("-start_time").values("sha")[:1]
    )

    # Apply conditions to the queryset if any filters were provided
    if query_conditions:
        queryset = PullRequest.objects.filter(query_conditions)
    else:
        # If no filters are provided, then fetch nothing to avoid loading unnecessary data
        queryset = PullRequest.objects

    queryset = queryset.prefetch_related(
        Prefetch("pr_labels"),
        Prefetch("pr_owners"),
    ).annotate(
        github_status=Case(
            When(state="closed", merge_commit_sha__isnull=False, then=Value("merged")),
            default=F("state"),
            output_field=CharField(),
        ),
        latest_commit=Max("pr_commits__submitted_time"),
        latest_build_status=Subquery(latest_build_status, output_field=CharField()),
        latest_build_url=Subquery(latest_build_url, output_field=CharField()),
        latest_build_id=Subquery(latest_build_id, output_field=CharField()),
        latest_build_run_id=Subquery(latest_build_run_id, output_field=CharField()),
        latest_build_sha=Subquery(latest_build_sha, output_field=CharField()),
    )

    total_rows = queryset.count()
    open_prs = queryset.filter(github_status="open").count()
    queryset = queryset.order_by(*order_fields)[offset : offset + limit]
    return list(queryset), total_rows, open_prs


def get_pr_runs(pr_id: int) -> List[PRCommitsAndRunsDTO]:
    # Fetch commits for a given PR
    commits = Commit.objects.filter(pr_id=pr_id).order_by("-submitted_time")
    builds = Build.objects.filter(pr_id=pr_id, job_name="sdk-pr-main").order_by("-build_run_id")

    builds_by_sha = {sha: [] for sha in commits}
    for build in builds:
        builds_by_sha.setdefault(build.sha, []).append(build)

    commit_data: List[PRCommitsAndRunsDTO] = []
    for commit in commits:
        # commit_dict = {"commit": commit, "builds": }
        commit_data.append(PRCommitsAndRunsDTO(commit, builds_by_sha.get(commit.sha, [])))

    return commit_data


def get_pr_details(pr_id: int) -> PullRequest:

    query_conditions = Q(id=pr_id)
    if query_conditions:
        queryset = PullRequest.objects.filter(query_conditions)
    else:
        queryset = PullRequest.objects

    queryset = queryset.prefetch_related(
        Prefetch("pr_labels"),
        Prefetch("pr_owners"),
    ).annotate(
        github_status=Case(
            When(state="closed", merge_commit_sha__isnull=False, then=Value("merged")),
            default=F("state"),
            output_field=CharField(),
        ),
    )

    return queryset.first()


def get_build_run_stages_status_bkp(build_id: int):

    stages = (
        StagesRun.objects.filter(Q(build__build_id=build_id) | Q(build__parent_build_id=build_id))
        .select_related("build")
        .prefetch_related("stages_tries")
    )

    exit_codes_set = ExitCode.objects.all().values("exit_code", "code_description")
    exit_codes = {item["exit_code"]: item["code_description"] for item in exit_codes_set}

    trigger_id_to_stage_id = {
        stage.build_triggered_id: stage.stage_id for stage in stages if stage.build_triggered_id is not None
    }

    # Update wrap_id for stages with build_id == build_triggered_id
    for stage in stages:
        triggered_id = trigger_id_to_stage_id.get(stage.build.build_id)
        if triggered_id:
            stage.wrap_id = triggered_id

    # Use the recursive function to build the tree from the root
    tree = build_tree(stages=list(stages), exit_codes=exit_codes)

    return tree


def build_tree_bkp(stages: list, exit_codes: dict, parent_id=None):
    """
    Recursively build the tree structure.
    """
    tree = []
    for stage in stages:
        if stage.wrap_id == parent_id:
            # This stage is a child of the current node
            node = {
                "id": stage.id,
                "name": stage.stage_name,
                "stage_status": stage.stage_status,
                "start_time": stage.start_time,
                "end_time": stage.end_time,
                "exit_code": stage.exit_code,
                "num_pass_tests": stage.num_pass_tests,
                "num_failed_tests": stage.num_failed_tests,
                "num_skipped_tests": stage.num_skipped_tests,
                "platform": stage.platform,
                "board_label": stage.board_label,
                "junit_path": stage.junit_path,
                "type": "TRIGGER" if stage.build_triggered_id else "STAGE",
                "tries": [
                    {
                        "try_id": try_obj.try_id,
                        "exit_code": try_obj.exit_code,
                        "board_ip": try_obj.board_ip,
                        "allocation_id": try_obj.allocation_id,
                        "body_start_time": try_obj.body_start_time,
                        "body_end_time": try_obj.body_end_time,
                        "junit_exists": try_obj.junit_exists,
                        # Add other fields as needed
                    }
                    for try_obj in stage.stages_tries.all()
                ],  # Access the related objects
                "children": build_tree(stages, exit_codes, parent_id=stage.stage_id),  # Recursion
            }
            # Update type to WRAPPER if there are children

            if node["exit_code"] and node["exit_code"] > 0:
                node["exit_code_description"] = exit_codes.get(node["exit_code"], "Unknown")

            if node["children"] and node.get("type", None) == "STAGE":
                node["type"] = "WRAPPER"

            if node["type"] in ["WRAPPER", "TRIGGER"]:
                node["build_url"] = stage.build.build_url

            tree.append(node)
    return tree


def fetch_custom_sql(build_id: int) -> List:
    sql = f"""
      SELECT s.*, st.try_id,st.exit_code as try_exit_code , board_ip,allocation_id,body_start_time,body_end_time,junit_exists
    FROM stages_run s
    INNER JOIN builds b ON b.build_id = s.build_id
    LEFT OUTER JOIN stages_run_tries st ON s.stage_id = st.stage_id AND s.build_id = st.build_id
    WHERE b.build_id = {build_id} OR b.parent_build_id =  {build_id}
    """

    result = execute_db_query(sql)
    return result


def process_row_into_structures(row, stages, stages_tries):
    stage_id = row["stage_id"]

    if stage_id not in stages:
        stages[stage_id] = row

    if "try_id" in row and row["try_id"] is not None:
        if stage_id not in stages_tries:
            stages_tries[stage_id] = []
        stages_tries[stage_id].append(
            {
                "try_id": row["try_id"],
                "board_ip": row["board_ip"],
                "exit_code": row["try_exit_code"],
                "allocation_id": row["allocation_id"],
            }
        )


def build_result_tree(stages, stages_tries, exit_codes, parent_id=None):
    tree = []
    for stage_id, stage in stages.items():
        if stage.get("wrap_id") == parent_id:
            node = {
                "stage_id": stage_id,
                "stage_name": stage["stage_name"],
                "stage_status": stage["stage_status"],
                "start_time": stage["start_time"],
                "end_time": stage["end_time"],
                "exit_code": stage["exit_code"],
                "num_pass_tests": stage["num_pass_tests"],
                "num_failed_tests": stage["num_failed_tests"],
                "num_skipped_tests": stage["num_skipped_tests"],
                "platform": stage["platform"],
                "board_label": stage["board_label"],
                "junit_path": stage["junit_path"],
                "exit_code_description": "",
                "tries": stages_tries.get(stage["stage_id"], []),
                "children": build_result_tree(
                    stages=stages, stages_tries=stages_tries, exit_codes=exit_codes, parent_id=stage["id"]
                ),
            }
            if node["exit_code"] and node["exit_code"] > 0:
                node["exit_code_description"] = exit_codes.get(node["exit_code"], "Unknown")

            node["type"] = "STAGE"
            if node["children"]:
                node["type"] = "TRIGGER" if stage["build_triggered_id"] else "WRAPPER"

            if node["type"] in ("TRIGGER", "WRAPPER"):
                node["stage_status"] = None

            tree.append(node)
    return tree


def get_build_run_stages_status(build_run_id: int, pr_id: int):
    # Fetch exit codes
    exit_codes_set = ExitCode.objects.all().values("exit_code", "code_description")
    exit_codes = {item["exit_code"]: item["code_description"] for item in exit_codes_set}

    build = Build.objects.filter(job_name="sdk-pr-main", pr_id=pr_id, build_run_id=build_run_id).first()
    # Fetch data using custom SQL
    raw_data = fetch_custom_sql(build.build_id)

    stages = {}
    stages_tries = {}
    trigger_id_to_stage_id = {}

    for row in raw_data:
        if row.get("build_triggered_id") is not None:
            trigger_id_to_stage_id[row["build_triggered_id"]] = row["id"]

    for row in raw_data:
        if trigger_id_to_stage_id.get(row["build_id"], None):
            row["wrap_id"] = trigger_id_to_stage_id.get(row["build_id"])

        process_row_into_structures(row, stages, stages_tries)

    tree = build_result_tree(stages, stages_tries, exit_codes)
    tree.sort(key=lambda x: x["start_time"])
    return tree


def get_pr_latest_commit(pr_id: int) -> Commit:

    get_object_or_404(PullRequest, id=pr_id)

    latest_commit = Commit.objects.filter(pr_id=pr_id).order_by("-submitted_time")[:1]
    return latest_commit.first()


def get_stable_tags_for_commit(pr_id: int) -> List[StableTag]:

    get_object_or_404(PullRequest, id=pr_id)

    relevant_tags = StableTag.objects.all()

    return relevant_tags


def build_pipeline_tree():
    # TODO : add schema validation to make sure that we get what we expect
    file_path = "lumina_input_pipline.json"
    with open(file_path, "r") as file:
        data = json.load(file)

    main_flow = data["pipline_flows"]["main_flow"]["flow_stages"]
    flows = data["pipline_flows"]
    stages = data["stages"]

    tree = build_tree(main_flow, flows, stages)
    simple_tree = simplify_tree(tree)

    return simple_tree


def build_tree(flow, flows, stages):
    if isinstance(flow, list):
        # Process each item in the list and collect results
        return [build_tree(item, flows, stages) for item in flow]
    elif isinstance(flow, dict):
        processed_node = []
        for key, value in flow.items():
            if key == "info":
                continue  # Skip the info block
            if isinstance(value, list):
                children = []
                for item in value:
                    if isinstance(item, str):
                        stage_details = stages.get(item)
                        if stage_details:
                            if stage_details["node_type"] == "stage":
                                child_node = {
                                    "name": item,
                                    "display_name": format_stage_name(item),
                                    "type": "stage",
                                    "config_run_status": stage_details["config_run_status"],
                                    "supports_fpr_partial_execution": stage_details["supports_fpr_partial_execution"],
                                    "device_name": stage_details["device_name"],
                                    "dependencies": (
                                        stage_details["dependencies"].split(",")
                                        if stage_details["dependencies"]
                                        else []
                                    ),
                                    "tags": stage_details["tags"].split(",") if stage_details["tags"] else [],
                                    # "children": [],
                                }
                                children.append(child_node)
                            elif stage_details["node_type"] == "sub_job":
                                sub_flow = flows.get(stage_details["flow_name"])
                                if sub_flow:
                                    sub_children = build_tree(sub_flow["stages"], flows, stages)
                                    children.append({"name": item, "type": "sub_job", "children": sub_children})
                        else:
                            children.append({"name": item, "type": "unknown", "children": []})
                    else:
                        # Nested structures
                        children.extend(build_tree(item, flows, stages))
                processed_node.append(
                    {"name": key, "display_name": format_stage_name(item), "type": "wrapper", "children": children}
                )
            else:
                # Process nested dictionaries directly
                processed_node.extend(build_tree(value, flows, stages))
        return processed_node
    else:
        # Return the node directly if it's neither a dict nor a list
        # return {"name": flow, "type": "unknown", "children": []}
        return


def simplify_tree(node):
    if isinstance(node, list):
        # Process each child in the list and flatten the list to avoid nested structures
        processed_list = []
        for child in node:
            result = simplify_tree(child)
            # If result is a list (possible from sub_job removal), extend rather than append
            if isinstance(result, list):
                processed_list.extend(result)
            else:
                processed_list.append(result)
        return processed_list
    elif isinstance(node, dict):
        if "children" in node:
            # Recursively simplify children
            node["children"] = simplify_tree(node["children"])
        # If the current node is a 'sub_job', return its children to replace this node
        if node["type"] == "sub_job":
            return node["children"]
        return node
    return node
