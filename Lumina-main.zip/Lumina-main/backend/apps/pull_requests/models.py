from django.db import models


class PullRequest(models.Model):
    id = models.IntegerField(primary_key=True)
    title = models.CharField(max_length=250)
    state = models.CharField(max_length=8)
    created_time = models.IntegerField()
    updated_time = models.IntegerField()
    closed_time = models.IntegerField(null=True, blank=True)
    target_branch = models.CharField(max_length=150)
    branch_name = models.CharField(max_length=250)
    merge_commit_sha = models.CharField(max_length=45, null=True, blank=True)

    class Meta:
        db_table = "pull_request"


class Commit(models.Model):
    id = models.BigIntegerField(primary_key=True)
    message = models.CharField(max_length=250)
    sha = models.CharField(max_length=45)
    merge_base_sha = models.CharField(max_length=45, null=True)
    pr = models.ForeignKey(PullRequest, on_delete=models.CASCADE, related_name="pr_commits")
    submitted_time = models.IntegerField()

    class Meta:
        db_table = "pr_commits"


class PRLabel(models.Model):
    id = models.AutoField(primary_key=True)
    pr = models.ForeignKey(PullRequest, on_delete=models.CASCADE, related_name="pr_labels")
    name = models.CharField(max_length=50)
    color = models.CharField(max_length=50)

    class Meta:
        db_table = "pr_labels"


class PROwner(models.Model):
    id = models.AutoField(primary_key=True)
    pr = models.ForeignKey(PullRequest, on_delete=models.CASCADE, related_name="pr_owners")
    role = models.CharField(max_length=50)
    user_name = models.CharField(max_length=50)

    class Meta:
        db_table = "pr_owners"


class ExitCode(models.Model):
    exit_code = models.IntegerField(primary_key=True)
    code_description = models.CharField(max_length=50)

    class Meta:
        db_table = "exit_codes"


class Build(models.Model):
    build_id = models.BigIntegerField(primary_key=True)
    job_name = models.CharField(max_length=45)
    build_url = models.CharField(max_length=200)
    build_run_id = models.IntegerField()
    pr = models.ForeignKey(PullRequest, on_delete=models.CASCADE, related_name="pr_builds")
    start_time = models.IntegerField()
    end_time = models.IntegerField(null=True)
    build_status = models.CharField(max_length=45)
    sha = models.CharField(max_length=45)
    parent_build_id = models.BigIntegerField(null=True, blank=True)

    class Meta:
        db_table = "builds"
        managed = False


class BuildSHA(models.Model):
    build = models.ForeignKey(Build, on_delete=models.CASCADE, related_name="build_shas")
    sha = models.CharField(max_length=45)

    class Meta:
        db_table = "builds_sha"
        unique_together = (("build", "sha"),)
        managed = False


class StagesRun(models.Model):
    id = models.BigAutoField(primary_key=True)
    stage_id = models.BigIntegerField()
    build = models.ForeignKey(Build, on_delete=models.CASCADE, related_name="build_stages")
    stage_name = models.CharField(max_length=100)
    stage_status = models.CharField(null=True, max_length=45)
    stage_run_id = models.IntegerField(null=True)
    start_time = models.IntegerField(null=True)
    end_time = models.IntegerField(null=True)
    retries = models.IntegerField(null=True)
    num_pass_tests = models.IntegerField(null=True)
    num_failed_tests = models.IntegerField(null=True)
    num_skipped_tests = models.IntegerField(null=True)
    build_triggered_id = models.BigIntegerField(null=True)
    junit_path = models.CharField(null=True, max_length=250)
    exit_code = models.IntegerField(null=True)
    board_label = models.CharField(null=True, max_length=50)
    platform = models.CharField(null=True, max_length=50)
    wrap_id = models.BigIntegerField(null=True)

    class Meta:
        # Ensuring that the combination of stage_id and build_id is unique
        unique_together = (("stage_id", "build_id"),)
        db_table = "stages_run"
        managed = False


class StagesRunTry(models.Model):
    id = models.BigAutoField(primary_key=True)
    try_id = models.IntegerField()
    stage_id = models.BigIntegerField()
    build_id = models.BigIntegerField()
    exit_code = models.IntegerField(null=True, default=None)
    board_ip = models.CharField(max_length=45, null=True, default=None)
    allocation_id = models.IntegerField(null=True, default=None)
    body_start_time = models.IntegerField(null=True, default=None)
    body_end_time = models.IntegerField(null=True, default=None)
    junit_exists = models.IntegerField(null=True, default=None)
    stages_run = models.ForeignKey(StagesRun, on_delete=models.CASCADE, related_name="stages_tries")

    class Meta:
        db_table = "stages_run_tries"
        unique_together = (("try_id", "stage_id", "build_id"),)


class TestsRun(models.Model):
    # Define the choices for the test_status field
    TEST_STATUS_CHOICES = [
        ("failed", "Failed"),
        ("passed", "Passed"),
        ("skipped", "Skipped"),
    ]

    test_id = models.BigIntegerField(primary_key=True)
    build = models.ForeignKey(Build, on_delete=models.CASCADE, related_name="build_tests")
    stage = models.ForeignKey(StagesRun, on_delete=models.CASCADE, related_name="build_stage_tests")
    test_name = models.CharField(max_length=450)
    class_name = models.CharField(max_length=450)
    test_status = models.CharField(max_length=20, choices=TEST_STATUS_CHOICES)
    test_duration = models.IntegerField(null=True)
    error_details = models.TextField(null=True)

    class Meta:
        unique_together = (("stage_id", "build_id", "test_id"),)
        db_table = "tests_run"
        managed = False


class StableTag(models.Model):
    id = models.BigIntegerField(primary_key=True)
    tag_name = models.CharField(max_length=50)
    branch_name = models.CharField(max_length=250)
    sha = models.CharField(max_length=45)
    date = models.IntegerField()

    class Meta:
        db_table = "stable_tags"
        managed = False
