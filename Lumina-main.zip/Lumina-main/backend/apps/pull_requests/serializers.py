from rest_framework import serializers
from django.conf import settings
import enum

from apps.pull_requests.models import Build, Commit


class PRLabelSerializer(serializers.Serializer):
    name = serializers.CharField(max_length=50)
    color = serializers.CharField(max_length=50)


class PROwnerSerializer(serializers.Serializer):
    user_name = serializers.CharField(max_length=50)
    role = serializers.CharField(max_length=50)


class PullRequestSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    title = serializers.CharField(max_length=250)
    created_time = serializers.IntegerField()
    closed_time = serializers.IntegerField(allow_null=True)
    target_branch = serializers.CharField(max_length=150)
    latest_commit = serializers.IntegerField(allow_null=True)
    pr_labels = PRLabelSerializer(many=True, read_only=True)
    pr_owners = PROwnerSerializer(many=True, read_only=True)
    github_link = serializers.SerializerMethodField()
    github_status = serializers.CharField(max_length=50)
    latest_build_status = serializers.CharField(required=False, max_length=50)
    latest_build_url = serializers.CharField(required=False, max_length=250)
    latest_build_id = serializers.IntegerField(required=False)
    latest_build_run_id = serializers.IntegerField(required=False)
    latest_build_sha = serializers.CharField(required=False, max_length=250)

    def get_github_link(self, obj):
        return f"{settings.GITHUB_BASE_URL}/pull/{obj.id}"


class PRListFiltersSerializer(serializers.Serializer):
    owners = serializers.ListField(child=serializers.CharField())
    target_branches = serializers.ListField(child=serializers.CharField())
    labels = serializers.ListField(child=serializers.CharField())


class PRListParamsSerializer(serializers.Serializer):
    pr_id = serializers.CharField(required=False)
    limit = serializers.IntegerField(required=False, help_text="Number of records to return")
    offset = serializers.IntegerField(required=False, help_text="Page number")
    order_by = serializers.CharField(required=False)
    title = serializers.CharField(required=False)
    label = serializers.CharField(required=False)
    owner = serializers.CharField(required=False, help_text="Owner can be the author , assignee or revier")
    order_by = serializers.CharField(required=False)
    target_branch = serializers.CharField(required=False)
    github_status = serializers.CharField(required=False)


class PRRunsParamsSerializer(serializers.Serializer):
    pr_id = serializers.IntegerField(required=False)


class PRDetailsParamsSerializer(serializers.Serializer):
    pr_id = serializers.IntegerField(required=False)


class BuildSerializer(serializers.ModelSerializer):
    class Meta:
        model = Build
        fields = ("build_run_id", "build_status", "build_url", "start_time", "build_id")


class PRRunsSerializer(serializers.Serializer):
    sha = serializers.SerializerMethodField()
    message = serializers.SerializerMethodField()
    submitted_time = serializers.SerializerMethodField()
    related_builds = serializers.SerializerMethodField()

    def get_sha(self, obj):
        return obj.commit.sha

    def get_message(self, obj):
        return obj.commit.message

    def get_submitted_time(self, obj):
        return obj.commit.submitted_time

    def get_related_builds(self, obj):
        return BuildSerializer(obj.builds, many=True).data


class PRDetailsSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    title = serializers.CharField(max_length=250)
    created_time = serializers.IntegerField()
    target_branch = serializers.CharField(max_length=150)
    branch_name = serializers.CharField(max_length=150)
    pr_labels = PRLabelSerializer(many=True, read_only=True)
    pr_owners = PROwnerSerializer(many=True, read_only=True)
    github_link = serializers.SerializerMethodField()
    github_status = serializers.CharField(max_length=50)

    def get_github_link(self, obj):
        return f"{settings.GITHUB_BASE_URL}/pull/{obj.id}"


class CommitSerializer(serializers.ModelSerializer):
    class Meta:
        model = Commit
        fields = ["id", "message", "sha", "merge_base_sha", "submitted_time"]


class TagType(enum.Enum):
    CUSTOM = "custom"
    STANDARD = "standard"


class StableTagSerializer(serializers.Serializer):
    tag_name = serializers.CharField(max_length=50)
    branch_name = serializers.CharField(max_length=250)
    sha = serializers.CharField(max_length=45)
    date = serializers.IntegerField()
    tag_type = serializers.SerializerMethodField()


def get_tag_type(self, obj):
    # Use the enum to determine the tag type
    if obj.tag_name == "latest_stable_simulation":
        return TagType.CUSTOM.value
    return TagType.STANDARD.value
