from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.pull_requests.dtos import PRLabelDto, PullRequestDto, PROwnerDto
from .services.pr_services import (
    get_pr_list_filters,
    get_pr_list,
    get_pr_runs,
    get_pr_details,
    get_build_run_stages_status,
    get_pr_latest_commit,
    get_stable_tags_for_commit,
    build_pipeline_tree,
)
from .services.github_services import (
    save_pr_commits_info,
    save_pr_info,
    sync_pr_info,
    save_pr_label_info,
    save_pr_owner_info,
    save_pr_info_all,
)
from .serializers import (
    PullRequestSerializer,
    PRListFiltersSerializer,
    PRListParamsSerializer,
    PRDetailsSerializer,
    PRRunsSerializer,
    StableTagSerializer,
    CommitSerializer,
)

from django.utils.decorators import method_decorator
from drf_spectacular.utils import extend_schema
from django.views.decorators.cache import cache_page
from django.views.decorators.vary import vary_on_cookie


class GitHubWebHook(APIView):
    # TODO add permissions handling for request from github
    authentication_classes = []
    permission_classes = [AllowAny]
    http_method_names = ["post", "head", "options"]

    def post(data, request, format=None):
        # Pull request actions:
        # opened
        # closed
        # reopened
        # edited
        # submitted
        # assigned
        # unassigned
        # review requested
        # review request removed
        # labeled
        # unlabeled
        # synchronize
        # ready for review
        # locked
        # unlocked
        action = request.data.get("action")
        if action == "opened":
            # New commit was pushed to PR branch , need to add it to DB
            pr_dto = PullRequestDto(request.data.get("pull_request"))
            save_pr_info_all(pr_dto)

        elif action in ["closed", "reopened", "edited"]:
            # Need to create a new record in pull_request table or update existing one
            pr_dto = PullRequestDto(request.data.get("pull_request"))
            save_pr_info(pr_dto)
        elif action == "synchronize":
            # New commit was pushed to PR branch , need to add it to DB
            pr_dto = PullRequestDto(request.data)
            save_pr_commits_info(pr_dto)
        elif action in ["labeled", "unlabeled"]:
            label_dto = PRLabelDto(pr_id=request.data["number"], label_json_data=request.data.get("label"))
            save_pr_label_info(label_dto, action)
        elif action in ["assigned", "unassigned"]:
            owner_dto = PROwnerDto(
                pr_id=request.data["number"], user_name=request.data.get("assignee")["login"], role="assignee"
            )
            save_pr_owner_info(owner_dto, action)

        elif action == "sync_pr_info":
            pr_id_list = request.data.get("pr_id_list")
            sync_pr_info(pr_id_list)

        return Response({"status": "Received"}, status=201)


class PRListFilters(APIView):
    authentication_classes = []
    permission_classes = [AllowAny]
    serializer_class = PRListFiltersSerializer

    @method_decorator(cache_page(60 * 60 * 2))
    @method_decorator(vary_on_cookie)
    def get(self, request):
        filters = get_pr_list_filters()
        serializer = PRListFiltersSerializer(instance=filters)
        return Response(serializer.data, status=200)


class PRListData(APIView):
    authentication_classes = []
    permission_classes = [AllowAny]
    serializer_class = PullRequestSerializer

    @extend_schema(parameters=[PRListParamsSerializer])
    def get(self, request):
        params_serializer = PRListParamsSerializer(data=request.query_params)
        params_serializer.is_valid(raise_exception=True)

        pr_list, total_rows, open_prs = get_pr_list(params=params_serializer.validated_data)
        serializer = PullRequestSerializer(pr_list, many=True)
        return Response({"count": total_rows, "open_prs": open_prs, "results": serializer.data}, status=200)


class PRRunsData(APIView):
    authentication_classes = []
    permission_classes = [AllowAny]
    serializer_class = PRRunsSerializer

    def get(self, request, pr_id):
        pr_runs = get_pr_runs(pr_id=pr_id)
        serializer = PRRunsSerializer(pr_runs, many=True)
        return Response(serializer.data, status=200)


class PRDetailsData(APIView):
    authentication_classes = []
    permission_classes = [AllowAny]
    serializer_class = PRDetailsSerializer

    def get(self, request, pr_id):
        pr_details = get_pr_details(pr_id=pr_id)
        serializer = PRDetailsSerializer(pr_details)
        return Response(serializer.data, status=200)


class PRRunStagesData(APIView):
    authentication_classes = []
    permission_classes = [AllowAny]
    serializer_class = PRDetailsSerializer

    def get(self, request, pr_id, build_run_id):
        pr_details = get_build_run_stages_status(build_run_id=build_run_id, pr_id=pr_id)
        # serializer = PRDetailsSerializer(pr_details)
        return Response(pr_details, status=200)


class PRLatestCommitDetails(APIView):
    authentication_classes = []
    permission_classes = [AllowAny]
    serializer_class = CommitSerializer

    def get(self, request, pr_id):
        pr_latest_commit_details = get_pr_latest_commit(pr_id=pr_id)
        serializer = CommitSerializer(pr_latest_commit_details)
        return Response(serializer.data, status=200)


class PRStableTags2Merge(APIView):
    authentication_classes = []
    permission_classes = [AllowAny]
    serializer_class = StableTagSerializer

    def get(self, request, pr_id):
        stable_tags = get_stable_tags_for_commit(pr_id=pr_id)
        serializer = StableTagSerializer(stable_tags, many=True)
        return Response(serializer.data, status=200)


class PRPipelineStages(APIView):
    authentication_classes = []
    permission_classes = [AllowAny]

    def get(self, request, pr_id):
        tree = build_pipeline_tree()
        return Response(tree, status=200)
