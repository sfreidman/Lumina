from dataclasses import dataclass, field
import re

from apps.core.dtos import BaseDTO
from apps.core.utils import date_to_unix_timestamp
from .models import Commit, Build
from typing import List


class PullRequestDto(BaseDTO):
    def __init__(self, json_data):
        self.pr = PRDto(json_data)
        self.labels_dto_list = [PRLabelDto(json_data.get("number"), label) for label in json_data.get("labels")]
        self.owners_dto_list = [
            PROwnerDto(pr_id=json_data.get("number"), role="assignee", user_name=user_name.get("login"))
            for user_name in json_data.get("assignees")
        ] + [PROwnerDto(pr_id=json_data.get("number"), role="author", user_name=json_data.get("user").get("login"))]


def sanitize_input(text):
    # This regex matches characters outside the Basic Multilingual Plane,
    # which includes emojis and other special characters not supported by utf8mb3.
    return re.sub(r"[^\u0000-\uFFFF]", "", text)


class PRDto(BaseDTO):
    def __init__(self, json_data):
        self.id = json_data.get("number")
        self.title = json_data.get("title")[:250]
        self.state = json_data.get("state")
        self.created_time = date_to_unix_timestamp(json_data.get("created_at"))
        self.updated_time = date_to_unix_timestamp(json_data.get("updated_at"))
        self.closed_time = date_to_unix_timestamp(json_data.get("closed_at"))
        self.branch_name = json_data.get("head").get("ref")
        self.target_branch = json_data.get("base").get("ref")
        self.merge_commit_sha = json_data.get("merge_commit_sha") if json_data.get("state") == "closed" else None


class PRLabelDto(BaseDTO):
    def __init__(self, pr_id: int, label_json_data: dict):
        self.pr_id = pr_id
        self.name = sanitize_input(label_json_data.get("name"))
        self.color = label_json_data.get("color")


class PRCommitDto(BaseDTO):
    def __init__(self, commit_json_data: dict, pr_id: int):
        self.id = get_hash_id(f"{commit_json_data.get('sha')},{pr_id}")
        self.sha = commit_json_data.get("sha")
        self.message = commit_json_data.get("commit").get("message")[:250]
        self.submitted_time = date_to_unix_timestamp(commit_json_data.get("commit").get("author").get("date"))
        self.merge_base_sha = None


class PROwnerDto(BaseDTO):
    def __init__(self, pr_id, role, user_name):
        self.pr_id = pr_id
        self.user_name = user_name
        self.role = role


@dataclass
class PRCommitsAndRunsDTO:
    commit: Commit
    builds: List[Build]


@dataclass
class PiplineNodeDTO:
    name: str
    type: str
    config_run_status: str = None
    supports_fpr_partial_execution: str = None
    device_name: str = None
    dependencies: List[str] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    children: List["PiplineNodeDTO"] = field(default_factory=list)
