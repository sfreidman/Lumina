# Lumina

## Getting Started

## Project Structure

## Additional Tools
1. Homebrew - Mac package manager
2. Pyenv - python version manager (if any issue, run `brew install xz` before installing it)
3. Poetry - Dependency management for python *(better than pip)*

## The Login Flow
First, our app id is: *DIBIF1TYQY6KCUTVSIJL*

You can generate a verifier & challenge with the following python code:
```python
code_verifier = base64.urlsafe_b64encode(os.urandom(60)).decode("utf-8")
code_challenge = hashlib.sha256(code_verifier.encode("utf-8")).digest()
code_challenge = base64.urlsafe_b64encode(code_challenge).decode("utf-8")
code_challenge = code_challenge.replace("=", "")
print("code_verifier: " + code_verifier)
print("code_challenge: " + code_challenge)
```
1. The make the following request in yout browser: 
```sh
# Notice to replace the {code_challenge} with what you generated above
https://sso-345c0691.sso.duosecurity.com/oidc/DIBIF1TYQY6KCUTVSIJL/authorize?response_type=code
  &client_id=DIBIF1TYQY6KCUTVSIJL
  &redirect_uri=http://localhost:3001
  &scope=openid email profile
  &code_challenge={code_challenge}
  &code_challenge_method=S256
```
2. After you approve, get the "code" from the URL that you got, it should look something like this: 

`http://localhost:3001/?code={some_code}`

3. Now with Postman (or anything that could POST) make the following request:
```sh
# Notice to replace the {code_verifier} with what you generated above and {code} with the one you just got
POST https://sso-345c0691.sso.duosecurity.com/oidc/DIBIF1TYQY6KCUTVSIJL/token
# body x-www-form-urlencoded
grant_type=authorization_code
client_id=DIBIF1TYQY6KCUTVSIJL
redirect_uri=http://localhost:3001
code={code}
code_verifier={code_verifier}
``` 

4. You should get 2 tokens back, *id_token* and *access_token*
5. You can with Postman make a get request and pass the access token as Authorization Bearer to:
```sh
https://sso-345c0691.sso.duosecurity.com/oidc/DIBIF1TYQY6KCUTVSIJL/userinfo
```
This will get you all user details
