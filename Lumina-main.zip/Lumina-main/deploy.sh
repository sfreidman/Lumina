#!/bin/bash
set -e

confirm() {
    # call with a prompt string or use a default
    read -r -p "${1:-Are you sure? [y/N]} " response
    case "$response" in
        [yY][eE][sS]|[yY]) 
            true
            ;;
        *)
            false 
            ;; 
    esac
} 

if confirm "Are you sure you want to deploy lumina to latest main? [y/N]"; then
    echo "Start deploying lumina to the server"
else
    echo "Exiting the deployment"
    exit 1
fi

cd backend
docker compose down

cd ..

cd frontend
docker compose down

cd ..

git fetch origin main
git reset --hard origin/main
chmod +x deploy.sh

cd backend
docker compose -f docker-compose-prod.yaml up -d --build
echo "Deploying lumina backend is done!"

cd ..

cd frontend
docker compose up -d --build
echo "Deploying lumina frontend is done!"

echo "Pruning all unused images..."
docker image prune -f
echo "Thank you, come again!"